/* eslint-disable max-len */
import api from '../utils/axios';
import {SAVE_USER_ROLE_URL as uri} from '../utils/Constants';

const saveUserRoleDetails = (body) => api.post(uri, body, {}, {});

const PersonalizeUserRoleService = {
  saveUserRoleDetails,
};
export default PersonalizeUserRoleService;
