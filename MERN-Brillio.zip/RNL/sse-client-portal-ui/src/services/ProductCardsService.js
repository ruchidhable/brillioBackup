/* eslint-disable max-len */
import api from '../utils/axios';
import {PRODUCT_CARDS_URL as uri} from '../utils/Constants';

const getProductCards = (ProductCategory) => api.get(uri, {'category' : ProductCategory}, {});

const ProductCardsService = {
  getProductCards,
};
export default ProductCardsService;
