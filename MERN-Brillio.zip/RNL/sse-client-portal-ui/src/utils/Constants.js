export const DEV_SUBSCRIBE_PRODUCT = '/SubscribedProductList';
export const SAVE_USER_ROLE_URL = '/save/saveUserDetails';
export const PRODUCT_CARDS_URL = '/IntegrationServiceDEV/productCategory';