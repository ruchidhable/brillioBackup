import { configureStore } from '@reduxjs/toolkit';
import welcomeSlice from '../slices/welcomeSlice';
import subscribedProductSlice from '../slices/subscribedProductSlice';
import productCards from '../slices/ProductCardsReducer';
import productTypeSlice from '../slices/productTypeSlice';
import personalizeUserRole from '../slices/PersonalizeUserRoleReducer';
import notifications from '../slices/NotificationReducer';

export const store = configureStore({
  reducer: {
    welcome: welcomeSlice.reducer,
    subscribedProducts: subscribedProductSlice.reducer,
    productCards: productCards.reducer,
    productType: productTypeSlice.reducer,
    personalizeUserRole: personalizeUserRole.reducer,
    notifications: notifications.reducer,
  },
});

export default store;
