/* eslint-disable max-len */
/* eslint-disable camelcase */
import Carousel from '../components/Carousel';
import ProductCards from '../components/ProductCards';

const productCardData = {
  id: 'Fundraising',
};

function Fundraising() {
  return (
    <>
      <Carousel />
      <ProductCards data={productCardData} />
    </>
  );
}
export default Fundraising;
