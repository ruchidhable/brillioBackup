/* eslint-disable max-len */
/* eslint-disable camelcase */
import Carousel from '../components/Carousel';
import ProductCards from '../components/ProductCards';

const productCardData = {
  id: 'StudentSuccess',
};

function Studentsuccess() {
  return (
    <>
      <Carousel />
      <ProductCards data={productCardData} />
    </>
  );
}
export default Studentsuccess;
