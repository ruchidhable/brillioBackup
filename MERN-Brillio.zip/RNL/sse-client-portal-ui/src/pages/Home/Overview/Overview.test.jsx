import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Overview from './Overview';
import { TaskTemplate } from './Overview';

test('renders Upload Data link', () => {
  render(<Overview />);
  const linkElement = screen.getByText(/View All/i);
  expect(linkElement).toBeInTheDocument();
});

test('renders Upload Data link', () => {
  render(<Overview />);
  const linkElement = screen.getByText(/Upload Data/i);
  expect(linkElement).toBeInTheDocument();
});

test('renders Upload Data link', () => {
  render(<Overview />);
  const linkElement = screen.getByText(/Launch WMJ/i);
  expect(linkElement).toBeInTheDocument();
});

test('load task template', () => {
  render(<TaskTemplate />);
});
