import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  notificationMessage: 'All Notifications',
  hideNotificationLabel: true,
};

const notificationReducer = createSlice({
  name: 'notifications',
  initialState,
  reducers: {
    getNotificationHeader : (state, action) => {
        state.hideNotificationLabel= action.payload;
    },
  },
});

export const { getNotificationHeader } = notificationReducer.actions;
export default notificationReducer;
