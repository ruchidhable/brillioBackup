/* eslint-disable no-param-reassign */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import saveUserRole from '../services/PersonalizeUserRoleService';

const initialState = {
  loading: false,
  userRoleDetailsState: [],
};

export const savePrimaryRoleDetails = createAsyncThunk('userRole/userRoleList', async (body) => {
  const response = await saveUserRole.saveUserRoleDetails(body);
  return response;
});

const PersonalizeUserRoleSlice = createSlice({
  name: 'UserRoleDetails',
  initialState,
  extraReducer: {
    [savePrimaryRoleDetails.fulfilled]: (state, action) => {
      state.userRoleDetailsState = action.payload;
      state.loading = false;
    },
    [savePrimaryRoleDetails.pending]: (state) => {
      state.loading = true;
    },
  },
});

export const userRoleSelector = (state) => state.UserRoleDetails;
export default PersonalizeUserRoleSlice;
