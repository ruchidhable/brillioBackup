import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import Header from '../Navigation/Header';
import theme from '../Navigation/Theme';
import Footer from './../Footer';

function Layout() {
  return (
    <ThemeProvider theme={theme}>
      <Header />
    </ThemeProvider>
  );
}
export default Layout;
