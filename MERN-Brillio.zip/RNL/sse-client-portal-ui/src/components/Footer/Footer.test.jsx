import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Footer from './Footer';

test('load Footer Component', () => {
  render(<Footer />);
});

test('renders Terms of Use link', () => {
  render(<Footer />);
  const linkElement = screen.getByText(/Terms of Use/i);
  expect(linkElement).toBeInTheDocument();
});

test('renders Privacy Policy link', () => {
  render(<Footer />);
  const linkElement = screen.getByText(/Privacy Policy/i);
  expect(linkElement).toBeInTheDocument();
});

test('renders Site Map link', () => {
  render(<Footer />);
  const linkElement = screen.getByText(/Site Map/i);
  expect(linkElement).toBeInTheDocument();
});
