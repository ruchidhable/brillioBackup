/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-props-no-spreading */
import * as React from 'react';
import { useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import Dialog from '@mui/material/Dialog';
import Alert from '@mui/material/Alert';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import { Grid, CardContent } from '@mui/material';
import './PersonalizeDialog.css';
import AccountBoxOutlinedIcon from '@mui/icons-material/AccountBoxOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import DriveFileMoveOutlinedIcon from '@mui/icons-material/DriveFileMoveOutlined';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import rnlRow from '../../../assets/Images/rnlRow1.png';
import {PERSONALIZATION} from '../../../MockData/Labels';

import {
  fetchSubscribedProduct,
  subscribedProductSelector,
} from '../../../slices/subscribedProductSlice';
import { savePrimaryRoleDetails } from '../../../slices/PersonalizeUserRoleReducer';
import {
  PersonalizeDialogTitle,
  PersonalizeDialogSubTitle,
  RoleTitle,
  RoleDetails,
  CardTemplate,
} from './PersonalizeDialogStyles';

const UserRoleAlert = React.forwardRef((props, ref) => (
  <Alert elevation={1} ref={ref} variant="filled" {...props} />
));

function PersonalizeDialog(props) {
  const productLabel = [
    { id: 1, name: 'RNL' },
    { id: 2, name: 'Omni' },
    { id: 3, name: 'Appli' },
    { id: 4, name: 'Dema' },
    { id: 5, name: 'GO' },
  ];

  const subscribedProducts = useSelector((state) => state.subscribedProducts);
  const dispatch = useDispatch();
  const products = subscribedProducts.data;

  const initFetch = useCallback(() => {
    dispatch(fetchSubscribedProduct());
  }, [dispatch]);

  useEffect(() => {
    initFetch();
  }, [initFetch]);

  const handleDialogClose = () => {
    props.setOpenDialog(false);
  };

  const [userRoleOpenAlert, setUserRoleOpenAlert] = React.useState(false);
  const [userRoleCloseAlert, setUserRoleCloseAlert] = React.useState(false);

  const handleCloseAlert = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setUserRoleOpenAlert(false);
  };

  const [userRoleDetails, setUserRoleDetails] = React.useState({});
  const [userRole, setUserRole] = React.useState('');

  const body = {
    email: PERSONALIZATION.EMAIL,
    role: userRole,
    roleDescription: userRole,
    firstName: PERSONALIZATION.FIRSTNAME,
    lastName: PERSONALIZATION.LASTNAME,
  };

  const initUserRoleDetails = () => {
    dispatch(savePrimaryRoleDetails(body)).then((response) => {
      setUserRoleDetails(response.payload);
      setUserRoleOpenAlert(true);
      setUserRoleCloseAlert(true);
      if (response.payload.response.data.statusCode !== 200) {
        setUserRoleCloseAlert(false);
      }
    });
  };

  return (
    <Dialog
      open={props.openDialog}
      PaperProps={{
        sx: {
          width: '956px',
          height: 'auto',
          maxWidth: '850px',
          overflowX: 'auto',
        },
      }}
    >
      <IconButton sx={{ position: 'absolute', right: 8, top: 8, color: '#838A91' }}>
        <CloseIcon onClick={handleDialogClose} />
      </IconButton>
      <Box sx={{ paddingTop: '70px', paddingBottom: '50px' }}>
        <div className="imgAlign">
          <ViewQuiltIcon sx={{ height: '47.95px', width: '47.92px', color: '#D9D8D8' }} />
        </div>
        <PersonalizeDialogTitle>
          Welcome Josh! Help us personalize your experience
        </PersonalizeDialogTitle>
        <PersonalizeDialogSubTitle sx={{ paddingBottom: '10px' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc a enim quis massa lobortis
          luctus. Phasellus eget odio felis. Donec et lacus vitae lacus.
        </PersonalizeDialogSubTitle>
        <PersonalizeDialogSubTitle
          sx={{ fontSize: '11px', paddingBottom: '10px', fontFamily: 'Helvetica Neue' }}
        >
          CURRENTLY SUBSCRIBED
        </PersonalizeDialogSubTitle>
        <div className="imgAlign">
          <img src={rnlRow} height="43px" />
        </div>
        <Grid container direction="row" justifyContent="flex-start" sx={{ paddingLeft: '216px' }}>
          {productLabel.map((product) => (
            <Grid item sx={{ paddingLeft: '45px', fontSize: '12px' }} key={product.id}>
              {product.name}
            </Grid>
          ))}
        </Grid>
      </Box>
      <Box
        sx={{
          background: 'linear-gradient(180deg, #F8F9FA 0%, #FCFDFD 100%)',
          paddingTop: '21px',
          paddingLeft: '25px',
          paddingRight: '25px',
        }}
      >
        <PersonalizeDialogTitle>What is your primary role?</PersonalizeDialogTitle>
        <PersonalizeDialogSubTitle sx={{ paddingBottom: '35px' }}>
          Choose the description that best aligns with your current role below
        </PersonalizeDialogSubTitle>
        <Grid container spacing={2}>
          <Grid
            item
            xs={4}
            onClick={() => {
              setUserRole('Executive');
            }}
          >
            <CardTemplate sx={{ maxWidth: 345 }}>
              <CardContent>
                <AccountBoxOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Executive
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
          <Grid
            item
            xs={4}
            onClick={() => {
              setUserRole('Day-to-Day Operations');
            }}
          >
            <CardTemplate>
              <CardContent>
                <DescriptionOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Day-to-Day Operations
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
          <Grid
            item
            xs={4}
            onClick={() => {
              setUserRole('Data Mover');
            }}
          >
            <CardTemplate sx={{ maxWidth: 345 }}>
              <CardContent>
                <DriveFileMoveOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Data Mover
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
        </Grid>
        <div className="imgAlign">
          <Button
            onClick={initUserRoleDetails}
            sx={{
              height: '48px',
              width: '159px',
              marginTop: '40px',
              marginBottom: '40px',
              borderRadius: '10px',
              backgroundColor: '#0071CE',
            }}
            variant="contained"
            size="large"
          >
            Save
          </Button>
          {userRoleCloseAlert ? (
            <Snackbar
              open={userRoleOpenAlert}
              autoHideDuration={2000}
              onClose={handleCloseAlert}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              <UserRoleAlert onClose={handleCloseAlert}
              sx={{backgroundColor:'#ccffcc', color:'#555a64', width: '100%' }}>
                Success!<p> Personalization choice: {userRole}</p>
              </UserRoleAlert>
            </Snackbar>
          ) : (
            <Snackbar
              open={userRoleOpenAlert}
              autoHideDuration={2000}
              onClose={handleCloseAlert}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              <UserRoleAlert onClose={handleCloseAlert} severity="warning" sx={{ width: '100%' }}>
                Something Went Wrong!
              </UserRoleAlert>
            </Snackbar>
          )}
        </div>
      </Box>
    </Dialog>
  );
}
export default PersonalizeDialog;
