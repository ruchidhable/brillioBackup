import { styled } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Link';
import { TableCell } from '@mui/material';

export const NotificationsTitle = styled(Typography)(() => ({
  height: '22px',
  width: '270px',
  color: '#002E5C',
  fontFamily: 'Helvetica',
  fontSize: '24px',
  fontWeight: 'bold',
  letterSpacing: '0',
  lineHeight: '22px',
  marginLeft: '25px',
  paddingLeft: '3px',
}));

export const NotificationsLabel = styled(Typography)(() => ({
  justifyContent: 'flex-start',
  paddingLeft: '10px',
  height: '32px',
  display: 'flex',
  alignItems: 'center',
  width: '180px',
  color: '#002E5C',
  fontFamily: 'Helvetica',
  fontSize: '14px',
  fontWeight: 'bold',
  letterSpacing: '0',
  lineHeight: '20px',
}));

export const NotificationType = styled(Typography)(() => ({
  height: '28px',
  width: '59px',
  color: '#2D3136',
  fontFamily: 'Helvetica',
  fontSize: '14px',
  fontWeight: 'bold',
  letterSpacing: 0,
  lineHeight: '32px',
  marginLeft: '7px',
}));

export const NotificationTemplate = styled(Typography)(() => ({
  height: '200px',
  textAlign: 'left',
  color: '#002E5C',
  fontFamily: 'Helvetica',
  boxShadow: 'none',
  paddingLeft: '15px',
  '&:hover': {
    borderLeft: '5px solid #0385F0',
    cursor: 'pointer',
    paddingLeft: '10px',
  },
}));

export const NotificationBody = styled(Typography)(() => ({
  color: 'black',
  fontSize: '14px',
  fontFamily: 'Helvetica Neue',
  paddingBottom: '10px',
  paddingLeft: '16px',
  width: '268px',
  color: '#2D3136',
  letterSpacing: '0',
  lineHeight: '22px',
  '&.MuiTypography-root': {
    fontFamily: 'inherit',
  },
}));

export const NotificationSourceLink = styled(Button)(() => ({
  paddingLeft: '11px',
  color: '#0F6DBE',
  fontFamily: 'Helvetica',
  display: 'flex',
  alignItems: 'center',
  fontSize: '14px',
  fontWeight: 'bold',
  '&:hover': {
    boxShadow: 'none',
    cursor: 'pointer',
  },
}));

export const NotificationTime = styled(Typography)(() => ({
  fontSize: '12px',
  fontFamily: 'Helvetica Neue',
  paddingLeft: '20px',
  color: '#5C666F',
  '&.MuiTypography-root': {
    fontFamily: 'inherit',
  },
}));

export const DismissLink = styled(Button)(() => ({
  color: '#002E5C',
  fontFamily: 'Helvetica Neue',
  fontSize: '12px',
  textAlign: 'right',
  '&.MuiTypography-root': {
    fontFamily: 'inherit',
  },
  '&:hover': {
    boxShadow: 'none',
    fontSize: '12px',
    cursor: 'pointer',
  },
}));

export const ViewAllLink = styled(Button)(() => ({
  paddingTop: '18px',
  paddingBottom: '14px',
  paddingLeft: '41px',
  color: '#0F6DBE',
  fontFamily: 'Helvetica',
  fontSize: '14px',
  fontWeight: 'bold',
  '&:hover': {
    boxShadow: 'none',
    cursor: 'pointer',
  },
}));

export const HeaderData = styled(TableCell)(() => ({
  color: '#2D3136',
  fontFamily: 'Helvetica',
  fontSize: '14px',
  fontWeight: 'bold',
  letterSpacing: '0px',
  lineHeight: '20px',
}));

export const RowData = styled(TableCell)(() => ({
  color: '#2D3136',
  fontFamily: 'Helvetica',
  fontSize: '13px',
}));
