import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Overview from "../pages/Home/Overview/Overview";
import Enrollment from '../pages/Enrollment';
import Fundraising from '../pages/Fundraising';
import Studentsuccess from '../pages/Studentsuccess';
import Header from '../components/Navigation/Header';
import EnrollmentDashboard from '../pages/Dashboard/EnrollmentDashboard';
import FundraisingDashboard from '../pages/Dashboard/FundraisingDashboard';
import StudentSuccessDashboard from '../pages/Dashboard/StudentSuccessDashboard';
import PageNotFound from '../pages/PageNotFound';
import ViewAllNotifications from '../components/Navigation/Notification/ViewAllNotifications';

function RouteComponent() {
  const data = useSelector((state) => state.productType);
  return (
    <Routes>
      <Route path="/" exact element={<Header />}>
        <Route
          path="/"
          element={
            data.userSubscribed ? (
              <Navigate replace to="/overview" />
            ) : (
              <Navigate replace to="/student-success" />
            )
          }
        />
        <Route path="/overview" element={<Overview />} />
        <Route path="/enrollment" element={<Enrollment />} />
        <Route path="/fundraising" element={<Fundraising />} />
        <Route path="/student-success" element={<Studentsuccess />} />
        <Route path="/enrollment-dashboard" element={<EnrollmentDashboard />} />
        <Route path="/student-success-dashboard" element={<StudentSuccessDashboard />} />
        <Route path="/fundraising-dashboard" element={<FundraisingDashboard />} />
        <Route path="/Notifications" element={<ViewAllNotifications/>}/>
        <Route path="*" element={<PageNotFound />} />
      </Route>
    </Routes>
  );
}
export default RouteComponent;
