import { configureStore } from '@reduxjs/toolkit';
import welcomeSlice from '../slices/welcomeSlice';
import subscribedProductSlice from '../slices/subscribedProductSlice';
import productCards from '../slices/ProductCardsSlice';
import productTypeSlice from '../slices/productTypeSlice';
import personalizeUserRole from '../slices/PersonalizeUserRoleSlice';
import notificationReducer from '../slices/NotificationSlice';
import tasksSlice from '../slices/tasksSlice';
import getPersonalizeUserRoleReducer from '../slices/getPersonalizeUserRoleSlice';
import getAllTasksReducer from '../slices/getAllTasksSlice';
import genericAlertReducer from '../slices/genericAlertSlice';
import errorAlertReducer from '../slices/errorMechanismSlice';

const store = configureStore({
  reducer: {
    welcome: welcomeSlice.reducer,
    subscribedProducts: subscribedProductSlice.reducer,
    productCards: productCards.reducer,
    productType: productTypeSlice.reducer,
    personalizeUserRole: personalizeUserRole.reducer,
    notifications: notificationReducer,
    tasks: tasksSlice.reducer,
    getPersonalizeUserRole: getPersonalizeUserRoleReducer,
    getAllTasks: getAllTasksReducer,
    genericAlert: genericAlertReducer,
    errorAlert: errorAlertReducer,
  },
});

export default store;
