/* eslint-disable no-param-reassign */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import fetchUserRole from '../services/GetPersonalizeUserRoleService';

const initialState = {
  loading: false,
  userRoleDetails: [],
  updateUserRoleDetails: [],
};

export const getPrimaryRoleDetails = createAsyncThunk('userRole/getUserRole', async () => {
  const response = await fetchUserRole.getUserRole();
  return response;
});

export const updatePrimaryRoleDetails = createAsyncThunk('userRole/updateUserRole', async (body) =>{
  const updatedRole = await fetchUserRole.updateUserRole(body);
  return updatedRole;
})

const GetPersonalizeUserRoleSlice = createSlice({
  name: 'GetUserRoleDetails',
  initialState,
  extraReducer: {
    [getPrimaryRoleDetails.fulfilled]: (state, action) => {
      state.userRoleDetails = action.payload;
      state.loading = false;
    },
    [getPrimaryRoleDetails.pending]: (state) => {
      state.loading = true;
    },
    [updatePrimaryRoleDetails.fulfilled]: (state, action) => {
      state.updateUserRoleDetails = action.payload;
      state.loading = false;
    },
    [updatePrimaryRoleDetails.pending]: (state) => {
      state.loading = true;
    },
  },
});

export const userRoleSelector = (state) => state.GetUserRoleDetails;
export default GetPersonalizeUserRoleSlice.reducer;
