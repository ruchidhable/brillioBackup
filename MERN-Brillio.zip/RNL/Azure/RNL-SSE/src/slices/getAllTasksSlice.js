/* eslint-disable no-param-reassign */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import allTasks from '../services/GetAllTasksService';

const initialState = {
  loading: false,
  allTasks: [],
};

export const getAllTasksDetails = createAsyncThunk('allTasksDetails/getAllTasks', async () => {
  const response = await allTasks.getAllTasks();
  return response;
});

const getAllTasksSlice = createSlice({
  name: 'allTasksDetails',
  initialState,
  extraReducers: {
    [getAllTasksDetails.fulfilled]: (state, action) => {
      state.allTasks = action.payload;
      state.loading = false;
    },
    [getAllTasksDetails.pending]: (state) => {
      state.loading = true;
    },
  },
});

export const allTasksSelector = (state) => state.allTasksDetails;
export default getAllTasksSlice.reducer;
