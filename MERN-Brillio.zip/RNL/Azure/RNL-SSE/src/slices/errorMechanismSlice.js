/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  errorTitle: '!Error',
  error: '',
  errorMessage: '',
  requestMethod: '',
  responseData: '',
  responseStatus: '',
  responseHeaders: '',
  errorRequest: '',
  errorConfig: '',
};

const errorMechanismSlice = createSlice({
  name: 'errorMechanism',
  initialState,
  reducers: {
    getErrorAlert: (state, action) => {
      state.errorTitle = action.payload.errorTitle;
      state.error = action.payload.error;
      state.errorMessage = action.payload.errorMessage;
      state.requestMethod = action.payload.requestMethod;
      state.responseData = action.payload.responseData;
      state.responseStatus = action.payload.responseStatus;
      state.responseHeaders = action.payload.responseHeaders;
      state.errorRequest = action.payload.errorRequest;
      state.errorConfig = action.payload.errorConfig;
    },
  },
});

export const { getErrorAlert } = errorMechanismSlice.actions;
export default errorMechanismSlice.reducer;
