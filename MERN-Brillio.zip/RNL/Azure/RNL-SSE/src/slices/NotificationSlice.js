/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  notificationsTitle: 'All Notifications',
  notifications: 'NOTIFICATIONS',
};

const notificationSlice = createSlice({
  name: 'notifications',
  initialState,
  reducers: {
    getNotificationHeader : (state, action) => {
      state.notificationsTitle = action.payload.notificationsTitle;
      state.notifications = action.payload.notifications;
    },
  },
});

export const { getNotificationHeader } = notificationSlice.actions;
export default notificationSlice.reducer;
