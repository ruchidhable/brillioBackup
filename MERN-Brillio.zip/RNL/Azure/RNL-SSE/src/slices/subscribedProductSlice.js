import { createSlice, createAsyncThunk, createSelector } from '@reduxjs/toolkit';
import SubscribedProductService from '../services/SubscribedProductService';

const initialState = {
  loading: false,
  data: [],
};

export const fetchSubscribedProduct = createAsyncThunk(
  'subscribedProducts/SubscribedProductList',
  async () => {
    const response = await SubscribedProductService.getSubscribedProducts();
    return response;
  },
);

const subscribedProductSlice = createSlice({
  name: 'subscribedProducts',
  initialState,
  extraReducers: {
    [fetchSubscribedProduct.fulfilled]: (state, action) => {
      state.data = action.payload;
      state.loading = false;
    },
    [fetchSubscribedProduct.pending]: (state) => {
      state.loading = true;
    },
  },
});

export const subscribedProductSelector = (state) => state;
export default subscribedProductSlice;
