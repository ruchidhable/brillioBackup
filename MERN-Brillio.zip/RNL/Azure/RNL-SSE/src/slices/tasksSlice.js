import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  taskLabel: 'TASKS',
  taskHeader: 'All Tasks',
  toggleTaskValue: true,
};

const tasksSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    showTasksHeader(state, action) {
      state.push({
        ...state,
        taskLabel: action.payload.taskLabel,
        taskHeader: action.payload.taskHeader,
      });
    },
    hideWelcomeHeader: (state) => {
      state.toggleTaskValue = false;
    },
  },
});

export const { showTasksHeader, hideWelcomeHeader } = tasksSlice.actions;
export default tasksSlice;
