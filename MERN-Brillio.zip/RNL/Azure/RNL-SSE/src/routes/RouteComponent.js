import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Overview from "../pages/Home/Overview/Overview";
import Enrollment from '../pages/Enrollment';
import Fundraising from '../pages/Fundraising';
import Studentsuccess from '../pages/Studentsuccess';
import NavBar from '../components/Navigation/NavBar';
import EnrollmentDashboard from '../pages/Dashboard/EnrollmentDashboard';
import FundraisingDashboard from '../pages/Dashboard/FundraisingDashboard';
import StudentSuccessDashboard from '../pages/Dashboard/StudentSuccessDashboard';
import OverviewAllTasks from '../pages/Tasks/OverviewAllTasks';
import PageNotFound from '../pages/PageNotFound';
import ViewAllNotifications from '../components/Navigation/Notification/ViewAllNotifications';
import GenericAlert from '../components/Alert';
import ErrorMechanism from '../components/ErrorMechanism';

function RouteComponent() {
  const data = useSelector((state) => state.productType);
  return (
    <Routes>
      <Route path="/" exact element={<NavBar />}>
        <Route
          path="/"
          element={
            data.userSubscribed ? (
              <Navigate replace to="/overview" />
            ) : (
              <Navigate replace to="/student-success" />
            )
          }
        />
        <Route path="/overview" element={<Overview />} />
        <Route path="/enrollment" element={<Enrollment />} />
        <Route path="/fundraising" element={<Fundraising />} />
        <Route path="/student-success" element={<Studentsuccess />} />
        <Route path="/enrollment-dashboard" element={<EnrollmentDashboard />} />
        <Route path="/student-success-dashboard" element={<StudentSuccessDashboard />} />
        <Route path="/fundraising-dashboard" element={<FundraisingDashboard />} />
        <Route path="/notifications" element={<ViewAllNotifications/>}/>
        <Route path="/tasks" element={<OverviewAllTasks />} />
        <Route path='/alert' element={GenericAlert} />
        <Route path="/error" element={ErrorMechanism}/>
        <Route path="*" element={<PageNotFound />} />
      </Route>
    </Routes>
  );
}
export default RouteComponent;
