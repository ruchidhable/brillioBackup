import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Notifications, { data } from './index';

// test block
test('render Notification', () => {
  expect('Notifications').toMatch(/Notifications/);
});

test('render View All', () => {
  expect('View All').toMatch(/All/);
});

test('null', () => {
  expect(data).not.toBeNull();
});
