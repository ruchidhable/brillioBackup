import { Grid } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import Divider from '@mui/material/Divider';
import { useSelector } from 'react-redux';
import { NotificationMessage, NotificationLabel } from './NotificationStyles';

function NotificationHeader() {
  const notificationData = useSelector((state) => state.notifications);

  return (
    <>
      <Grid container sx={{ width: 'auto', mt: 4, alignItem: 'center' }}>
        <Grid item sx={{ paddingLeft: '20px', paddingRight: '20px', marginTop: '13px' }}>
          <HomeIcon sx={{ fontSize: 21, mt: -1, color: '#0F6DBE' }} />
        </Grid>
        <Divider
          orientation="vertical"
          sx={{
            height: 13,
            border: 0.1,
            color: '#696F76',
            mt: 1.7,
          }}
        />
        <Grid item>
          <NotificationLabel>{notificationData.notifications}</NotificationLabel>
        </Grid>
      </Grid>
      <Grid container>
        <Grid item>
          <NotificationMessage>{notificationData.notificationsTitle}</NotificationMessage>
        </Grid>
      </Grid>
    </>
  );
}
export default NotificationHeader;
