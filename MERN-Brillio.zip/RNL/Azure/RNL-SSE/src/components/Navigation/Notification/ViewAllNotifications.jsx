import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import TableRow from '@mui/material/TableRow';
import { Divider, TableHead } from '@mui/material';
import NotificationData from '../../../MockData/notifications.json';
import { RowData, HeaderData } from './NotificationStyles';
import NotificationHeader from './NotificationHeader';

function ViewAllNotifications() {
  return (
    <div>
      <NotificationHeader />
      <Divider sx={{ mt: '10px' }} />
      <TableContainer
        sx={{
          m: 2,
          border: 1,
          borderColor: '#EBECED',
          borderRadius: '3px',
          boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
        }}
        style={{ width: '1160px' }}
      >
        <Table>
          <TableHead>
            <TableRow>
              <HeaderData sx={{ width: '13%' }}>Notifications</HeaderData>
              <HeaderData sx={{ width: '40%' }}>Descprictions</HeaderData>
              <HeaderData sx={{ width: '8%' }}>Type</HeaderData>
              <HeaderData>Time</HeaderData>
            </TableRow>
          </TableHead>
          <TableBody>
            {NotificationData.map((data) => (
              <TableRow key={data.id}>
                <RowData>{data.title}</RowData>
                <RowData>{data.description}</RowData>
                <RowData sx={{ color: '#0071CE', fontWeight: 'bold' }}>{data.type}</RowData>
                <RowData>{data.time}</RowData>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}
export default ViewAllNotifications;
