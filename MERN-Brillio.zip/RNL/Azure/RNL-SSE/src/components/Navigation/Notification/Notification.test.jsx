import React from 'react';
import { render } from '@testing-library/react';
import Notification from './index';

// test block
test('render Notification Text', () => {
  expect('View More').toMatch(/ore/);
});

test('render Notification Text', () => {
  expect('Notification').toMatch(/cat/);
});
