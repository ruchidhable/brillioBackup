/* eslint-disable react/jsx-no-useless-fragment */
import * as React from 'react';
import SwipeableDrawer from '@mui/material/SwipeableDrawer';
import Select from '@mui/material/Select';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import Stack from '@mui/material/Stack';
import Divider from '@mui/material/Divider';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useNavigate } from 'react-router-dom';
import bulb from '../../../assets/Images/bulb.png';
import wmj from '../../../assets/Images/wmj.png';
import data from '../../../MockData/notifications.json';
import warning from '../../../assets/Images/warning.png';
import {
  NotificationsTitle,
  NotificationsLabel,
  NotificationBody,
  NotificationSourceLink,
  NotificationTime,
  DismissLink,
  ViewAllLink,
  NotificationType,
  NotificationTemplate,
} from './NotificationStyles';
import './Notification.css';

function Notification(props) {
  const navigate = useNavigate();
  const [list, setList] = React.useState(data);

  const handleNotificationClose = () => {
    props.setOpenNotification(false);
  };

  const handleDismiss = (id) => {
    const newList = list.filter((item) => item.id !== id);
    setList(newList);
  };

  const handleAllNotifications = () => {
    handleNotificationClose();
    navigate('/notifications');
  };

  return (
    <>
      {list.length > 0 ? (
        <SwipeableDrawer
          PaperProps={{
            style: {
              overflowY: 'auto',
              height: 'auto',
              maxHeight: '580px',
              width: '360px',
              borderRadius: '7px',
            },
          }}
          keepMounted
          anchor="right"
          open={props.openNotification}
          onClose={handleNotificationClose}
        >
          <NotificationsTitle mt="90px">Notifications</NotificationsTitle>
          <br />
          <span>
            <NotificationType
              className="typeLabel"
              sx={{
                display: 'inline',
                justifyContent: 'space-between',
                pl: '24px',
                marginRight: '9px',
              }}
            >
              Type
            </NotificationType>

            <Select
              name="type"
              id="type"
              sx={{ width: '91px', height: '28px' }}
              selected="selected"
            >
              <MenuItem value="All" selected>
                All
              </MenuItem>
              <MenuItem value="Type1">Type1</MenuItem>
              <MenuItem value="Type2">Type2</MenuItem>
              <MenuItem value="Type2">Type3</MenuItem>
            </Select>
          </span>
          <br /> <br />
          {list.map((item) => (
            <div key={item.id}>
              <Box
                sx={{
                  width: '342px',
                  textAlign: 'left',
                  mt: '3px',
                }}
                spacing={3}
                direction="column"
              >
                <Stack>
                  <NotificationTemplate>
                    <NotificationsLabel gutterBottom component="div">
                      <img
                        style={{ paddingRight: '7px', height: '24px', width: '30px' }}
                        src={warning}
                        alt="img link"
                      />
                      <b>{item.title}</b>
                    </NotificationsLabel>

                    <NotificationBody variant="body2" gutterBottom>
                      {item.description}
                    </NotificationBody>
                    <NotificationSourceLink underline="none">
                      <img style={{ paddingRight: '4px' }} src={wmj} alt="source link" />
                      {item.type}
                      <ArrowForwardIosIcon
                        sx={{
                          color: '#0F6DBE',
                          height: '10.9px',
                          width: '12.2px',
                        }}
                      />
                    </NotificationSourceLink>
                    <Grid item container sx={{ pt: '17px' }}>
                      <Grid item sx={{ gridRow: '1', gridColumn: 'span 2' }}>
                        <NotificationTime>{item.time}</NotificationTime>
                      </Grid>

                      <Grid item sx={{ paddingLeft: '130px' }}>
                        <DismissLink underline="always" onClick={() => handleDismiss(item.id)}>
                          Dismiss
                        </DismissLink>
                      </Grid>
                    </Grid>
                  </NotificationTemplate>
                </Stack>
              </Box>
              <Divider
                variant="fullWidth"
                sx={{ border: '1px solid #EDEDED' }}
                className="divider1"
              />
            </div>
          ))}
          <ViewAllLink underline="none" onClick={handleAllNotifications}>
            <b>View All</b>
            <ArrowForwardIosIcon
              sx={{
                color: '#0F6DBE',
                height: '10.9px',
                width: '12.2px',
              }}
            />
          </ViewAllLink>
        </SwipeableDrawer>
      ) : null}
    </>
  );
}

export default Notification;
