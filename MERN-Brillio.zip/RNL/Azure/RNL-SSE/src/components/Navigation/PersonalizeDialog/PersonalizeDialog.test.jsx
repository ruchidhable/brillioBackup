import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import PersonalizeDialog from './index';

// test block
test('render Primary role', () => {
  expect('Primary').toMatch(/mar/);
});

test('render Executive', () => {
  expect('Executive').toMatch(/cut/);
});

test('render Welcome Text', () => {
  expect('Welcome').toMatch(/come/);
});
