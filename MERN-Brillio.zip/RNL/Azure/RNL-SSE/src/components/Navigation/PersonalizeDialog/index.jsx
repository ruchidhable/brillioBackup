/* eslint-disable max-len */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
/* eslint-disable radix */
/* eslint-disable no-use-before-define */
/* eslint-disable react/jsx-props-no-spreading */
import * as React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import { Grid, CardContent } from '@mui/material';
import './PersonalizeDialog.css';
import AccountBoxOutlinedIcon from '@mui/icons-material/AccountBoxOutlined';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import DriveFileMoveOutlinedIcon from '@mui/icons-material/DriveFileMoveOutlined';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import rnlRow from '../../../assets/Images/rnlRow1.png';
import { PERSONALIZATION, ALERT } from '../../../MockData/Labels';
import {
  fetchSubscribedProduct,
  subscribedProductSelector,
} from '../../../slices/subscribedProductSlice';
import { savePrimaryRoleDetails } from '../../../slices/PersonalizeUserRoleSlice';
import {
  PersonalizeDialogTitle,
  PersonalizeDialogSubTitle,
  RoleTitle,
  RoleDetails,
  CardTemplate,
} from './PersonalizeDialogStyles';
import {
  getPrimaryRoleDetails,
  updatePrimaryRoleDetails,
} from '../../../slices/getPersonalizeUserRoleSlice';
import GenericAlert from '../../Alert';
import { getAlert } from '../../../slices/genericAlertSlice';

function PersonalizeDialog(props) {
  const productLabel = [
    { id: 1, name: 'RNL' },
    { id: 2, name: 'Omni' },
    { id: 3, name: 'Appli' },
    { id: 4, name: 'Dema' },
    { id: 5, name: 'GO' },
  ];

  const subscribedProducts = useSelector((state) => state.subscribedProducts);
  const dispatch = useDispatch();
  const products = subscribedProducts.data;

  const initFetch = useCallback(() => {
    dispatch(fetchSubscribedProduct());
  }, [dispatch]);

  useEffect(() => {
    initFetch();
  }, [initFetch]);

  const [fetchUserRole, setFetchUserRole] = useState('');
  const [updatedUserRole, setUpdatedUserRole] = useState(fetchUserRole);
  const [isError, setIsError] = useState(false);

  const fetchRole = () => {
    let errorResponse;
    dispatch(getPrimaryRoleDetails()).then((response) => {
      if (response.payload[0] !== undefined) {
        setFetchUserRole(response.payload[0].role);
      } else {
        errorResponse = {
          errorTitle: '!Error',
          error: response,
          errorMessage: response.payload.message,
          reqestMethod: response.payload.config.method,
          responseData: '',
          responseStatus: response.payload.request.status,
          responseHeaders: '',
          errorRequest: response.payload.config.url,
          errorConfig: response.payload.config,
        };
        dispatch(getErrorAlert(errorResponse));
        // Console.log is used to display the error info
        console.log(
          errorResponse.reqestMethod,
          errorResponse.responseStatus,
          errorResponse.errorRequest,
          'Error: ',
          errorResponse.errorMessage,
        );
        setIsError(true);
      }
      return response;
    });
  };
  fetchRole();

  useEffect(() => {
    if (fetchUserRole === 'Executive') {
      roleListItem[0] = true;
    } else if (fetchUserRole === 'Day to Day Operations') {
      roleListItem[1] = true;
    } else if (fetchUserRole === 'Data Mover') {
      roleListItem[2] = true;
    }
  }, [fetchUserRole]);

  const handleDialogClose = () => {
    props.setOpenDialog(false);
    dispatch(getAlert({ openAlert: false }));
  };

  const [userRoleOpenAlert, setUserRoleOpenAlert] = React.useState(false);
  const [userRoleCloseAlert, setUserRoleCloseAlert] = React.useState(false);

  const [userRoleDetails, setUserRoleDetails] = React.useState({});
  const [disableSaveButton, setDisableSaveButton] = useState(true);

  const userRoleCSS = {
    border: '2px solid #0F6DBE',
    borderRadius: '3px',
    cursor: 'pointer',
  };

  const [roleListItem, setRoleListItem] = React.useState([false, false, false]);
  const updateUserRole = (role) => {
    setUpdatedUserRole(role);
  };

  const changeCss = (e) => {
    const roleItem = [false, false, false];
    e.preventDefault();
    e.stopPropagation();
    updateUserRole(e.currentTarget.getAttribute('value'));
    const selectedItem = parseInt(e.currentTarget.getAttribute('data-index'));
    let i;
    for (i = 0; i < roleItem.length; i += 1) {
      if (i === selectedItem) {
        roleItem[i] = true;
      } else {
        roleItem[i] = false;
      }
    }
    setRoleListItem(roleItem);
  };

  useEffect(() => {
    if (updatedUserRole === '' || fetchUserRole === updatedUserRole) {
      setDisableSaveButton(true);
    } else {
      setDisableSaveButton(false);
    }
  }, [updatedUserRole]);

  const saveUserRoleBody = {
    email: PERSONALIZATION.EMAIL,
    role: updatedUserRole,
    roleDescription: updatedUserRole,
    firstName: PERSONALIZATION.FIRSTNAME,
    lastName: PERSONALIZATION.LASTNAME,
  };

  const updateUserRoleBody = {
    email: PERSONALIZATION.EMAIL,
    role: updatedUserRole,
    roleDescription: updatedUserRole,
  };

  const successAlertMessage = {
    alertTitle: ALERT.SUCCESS_TITLE,
    alertMessage: ALERT.SUCCESS_SUBTEXT + updatedUserRole,
    openAlert: true,
    alertType: ALERT.TYPE,
  };

  const errorAlertMessage = {
    alertTitle: ALERT.ERROR_TITLE,
    alertMessage: ALERT.ERROR_SUBTEXT + updatedUserRole,
    openAlert: true,
    alertType: '',
  };

  const initUserRoleDetails = () => {
    dispatch(savePrimaryRoleDetails(saveUserRoleBody)).then((response) => {
      setUserRoleDetails(response.payload);
      setUserRoleOpenAlert(true);
      setUserRoleCloseAlert(true);
      if (response.payload.response.data.statusCode !== 200) {
        setUserRoleCloseAlert(false);
        dispatch(getAlert(errorAlertMessage));
      } else {
        dispatch(getAlert(successAlertMessage));
      }
    });
    fetchRole();
    setTimeout(() => {
      handleDialogClose();
    }, 4000);
  };

  const updateUserRoleDetails = () => {
    dispatch(updatePrimaryRoleDetails(updateUserRoleBody)).then((response) => {
      setUserRoleDetails(response.payload);
      setUserRoleOpenAlert(true);
      setUserRoleCloseAlert(true);
      if (response.meta.requestStatus !== 'fulfilled') {
        setUserRoleCloseAlert(false);
        dispatch(getAlert(errorAlertMessage));
      } else {
        dispatch(getAlert(successAlertMessage));
      }
    });
    fetchRole();
    setTimeout(() => {
      handleDialogClose();
    }, 4000);
  };

  return (
    <Dialog
      open={props.openDialog}
      PaperProps={{
        sx: {
          width: '956px',
          height: 'auto',
          maxWidth: '850px',
          overflowX: 'auto',
        },
      }}
    >
      <IconButton
        onClick={handleDialogClose}
        sx={{ position: 'absolute', right: 8, top: 8, color: '#838A91' }}
      >
        <CloseIcon />
      </IconButton>
      <Box sx={{ paddingTop: '70px', paddingBottom: '50px' }}>
        <div className="imgAlign">
          <ViewQuiltIcon sx={{ height: '47.95px', width: '47.92px', color: '#D9D8D8' }} />
        </div>
        <PersonalizeDialogTitle>
          Welcome Josh! Help us personalize your experience
        </PersonalizeDialogTitle>
        <PersonalizeDialogSubTitle sx={{ paddingBottom: '10px' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc a enim quis massa lobortis
          luctus. Phasellus eget odio felis. Donec et lacus vitae lacus.
        </PersonalizeDialogSubTitle>
        <PersonalizeDialogSubTitle
          sx={{ fontSize: '11px', paddingBottom: '10px', fontFamily: 'Helvetica Neue' }}
        >
          CURRENTLY SUBSCRIBED
        </PersonalizeDialogSubTitle>
        <div className="imgAlign">
          <img src={rnlRow} alt="" height="43px" />
        </div>
        <Grid container direction="row" justifyContent="flex-start" sx={{ paddingLeft: '216px' }}>
          {productLabel.map((product) => (
            <Grid item sx={{ paddingLeft: '45px', fontSize: '12px' }} key={product.id}>
              {product.name}
            </Grid>
          ))}
        </Grid>
      </Box>
      <Box
        sx={{
          background: 'linear-gradient(180deg, #F8F9FA 0%, #FCFDFD 100%)',
          paddingTop: '21px',
          paddingLeft: '25px',
          paddingRight: '25px',
        }}
      >
        <PersonalizeDialogTitle>What is your primary role?</PersonalizeDialogTitle>
        <PersonalizeDialogSubTitle sx={{ paddingBottom: '35px' }}>
          Choose the description that best aligns with your current role below
        </PersonalizeDialogSubTitle>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <CardTemplate
              data-index="0"
              sx={{ maxWidth: 345 }}
              value="Executive"
              onClick={changeCss}
              style={roleListItem[0] ? userRoleCSS : null}
            >
              <CardContent>
                <AccountBoxOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Executive
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
          <Grid item xs={4}>
            <CardTemplate
              data-index="1"
              value="Day to Day Operations"
              onClick={changeCss}
              style={roleListItem[1] ? userRoleCSS : null}
            >
              <CardContent>
                <DescriptionOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Day-to-Day Operations
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
          <Grid item xs={4}>
            <CardTemplate
              data-index="2"
              sx={{ maxWidth: 345 }}
              value="Data Mover"
              onClick={changeCss}
              style={roleListItem[2] ? userRoleCSS : null}
            >
              <CardContent>
                <DriveFileMoveOutlinedIcon className="roleIcon" />
                <RoleTitle gutterBottom variant="h3" component="div">
                  Data Mover
                </RoleTitle>
                <RoleDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Oversees a team of doers </li>
                    <li>Lorem ipisum dolor sit amet</li>
                    <li>Lorem ipsum dolor sit amet</li>
                  </ul>
                </RoleDetails>
              </CardContent>
            </CardTemplate>
          </Grid>
        </Grid>
        <div className="imgAlign">
          <Button
            disabled={disableSaveButton}
            onClick={fetchUserRole === '' ? initUserRoleDetails : updateUserRoleDetails}
            sx={{
              height: '48px',
              width: '159px',
              marginTop: '40px',
              marginBottom: '40px',
              borderRadius: '10px',
              backgroundColor: '#0071CE',
            }}
            variant="contained"
            size="large"
          >
            Save
          </Button>
          <GenericAlert />
          {isError ? <ShowError /> : ''}
        </div>
      </Box>
    </Dialog>
  );
}
export default PersonalizeDialog;
