import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import NavBar from './index';

// test block
test('render Header', () => {
  expect('RNL Dashboard').toMatch(/RNL/);
});

test('render Smart View', () => {
  expect('Smart View').toMatch(/View/);
});
