import { styled } from '@mui/material/styles';

export const IconButton = styled(IconButton)(() => ({
  marginTop: 6,
  marginLeft: -9,
  marginRight: 10,
  width: 25,
  Height: 20,
}));
