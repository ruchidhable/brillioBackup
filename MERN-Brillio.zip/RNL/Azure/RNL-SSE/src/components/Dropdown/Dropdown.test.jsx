import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Dropdown from './index';

test('render Dropdown Item', () => {
  expect('Overview').toMatch(/view/);
});

test('render Dropdown Item', () => {
  expect('Student Success').toMatch(/ss/);
});

test('render Dropdown Item', () => {
  expect('Enrollement').toMatch(/ll/);
});
