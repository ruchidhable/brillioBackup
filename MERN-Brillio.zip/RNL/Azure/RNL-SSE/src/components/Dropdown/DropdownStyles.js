import { Grid } from '@mui/material';
import { styled } from '@mui/material/styles';

export const DropdownIcon = styled(Grid)(() => ({
  width: 21,
  height: 21,
  marginRight: 8,
  color: '#89949E',
}));
