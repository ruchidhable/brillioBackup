import * as React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Snackbar from '@mui/material/Snackbar';
import { Alert } from '@mui/material';

const UserRoleAlert = React.forwardRef((props, ref) => (
  <Alert elevation={1} ref={ref} variant="filled" {...props} />
));

export default function ErrorMechanism() {
  const [userRoleOpenAlert, setUserRoleOpenAlert] = useState(true);
  const errorData = useSelector((state) => state.errorAlert);

  const handleCloseAlert = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setUserRoleOpenAlert(false);
  };

  return (
    <div>
      <Snackbar
        open={userRoleOpenAlert}
        autoHideDuration={3000}
        onClose={handleCloseAlert}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <UserRoleAlert
          onClose={handleCloseAlert}
          severity="warning"
          sx={{
            background: '#FFCADA',
            color: '#b30000',
            border: '3px solid #b30000',
            width: '100%',
          }}
        >
          {errorData.errorTitle}
          <p>{errorData.errorMessage}</p>
        </UserRoleAlert>
      </Snackbar>
    </div>
  );
}
