/* eslint-disable react/no-unstable-nested-components */
import React, { useRef, useState } from 'react';
import Slider from 'react-slick';
import Container from '@mui/material/Container';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIos from '@mui/icons-material/ArrowForwardIos';
import banner from '../../assets/Images/banner.png';
import { CarousalArrowIosIconBack, CarousalArrowIosIconForword } from './CarousalStyles';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './carousalStyles.css';
import paginationCarousal from '../../assets//Images/carousalPagination.png';

export default function Carousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const customSlider = useRef();
  const gotoNext = () => {
    customSlider.current.slickNext();
  };

  const gotoPrev = () => {
    customSlider.current.slickPrev();
  };

  const sliderCSS ={
    slickActive:{
      color:'#6B7782',
      backgroundImage:`url("${paginationCarousal}")`,
      backgroundRepeat:'no-repeat',
      backgroundSize: '40px',
      lineHeight: '40px',
      width:'40px',
    },
    slickInActive:{
      color:'#6B7782',
    }
  }

  const settings = {
    beforeChange: (current, next) =>{
      setCurrentIndex(next);
    },
    customPaging(i) {
      return (
        <div style={currentIndex==i ? sliderCSS.slickActive : sliderCSS.slickInActive}>
          {i+1}
        </div>
      );
    },
    appendDots: (dots) => (
      <div>
        <CarousalArrowIosIconBack sx={{mr:'550px'}} >
          <ArrowBackIosIcon sx={{ height: 15 }} onClick={() => gotoPrev()} />
        </CarousalArrowIosIconBack>
        <ul className='slick-dots li'>{dots}</ul>
        <CarousalArrowIosIconForword sx={{ml:'-300px'}}>
          <ArrowForwardIos sx={{ height: 15 }} onClick={() => gotoNext()} />
        </CarousalArrowIosIconForword>
      </div>
    ),
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    focusOnSelect: true,
  };
  return (
    <Container disableGutters sx={{ mt: -0.1, maxWidth: '1214px' }} maxWidth={false}>
      <Slider ref={customSlider} {...settings}>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
        <div>
          <img src={banner} alt="" style={{ width: '100%' }} />
        </div>
      </Slider>
    </Container>
  );
}
