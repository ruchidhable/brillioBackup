import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import Footer from './index';
import store from '../../store';

test('load Footer Component', () => {
  render(
    <Provider store={store}>
      <Footer />
    </Provider>,
  );
});

test('render Footer Text', () => {
  expect('Reserved').toMatch(/er/);
});
