/* eslint-disable arrow-body-style */
/* eslint-disable react/function-component-definition */
import Paper from '@mui/material/Paper';
import CopyrightIcon from '@mui/icons-material/Copyright';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import { FooterDetails, FooterLink, FooterDivider } from './FooterStyles';

const Footer = () => {
  return (
    <Paper
      sx={{
        height: '93px',
        width: '1200px',
        marginTop: 'calc(100% - 1250px);',
        position: 'absolute',
        backgroundColor: '#FFFFFF',
        display: 'flex',
        alignItems: 'center',
      }}
    >
      <CopyrightIcon sx={{ color: '#89949E', height: '7px', width: '7px', marginLeft: '22px' }} />
      <FooterDetails>1998-2022 Ruffalo Noel Levitz, LLC.All Rights Reserved.</FooterDetails>
      <FooterLink underline="none" sx={{ paddingLeft: '250px' }}>
        Terms of Use
      </FooterLink>
      <FooterDivider
        variant="middle"
        flexItem
        sx={{ borderLeft: '2px solid #E9EAEB', height: '30px', width: '1px', marginTop: '31px' }}
      />
      <FooterLink underline="none" sx={{ padding: '0px !important' }}>
        Privacy Policy
      </FooterLink>
      <FooterDivider
        variant="middle"
        flexItem
        sx={{ borderLeft: '2px solid #E9EAEB', height: '30px', width: '1px', marginTop: '31px' }}
      />
      <FooterLink underline="none" sx={{ padding: '0px !important', marginRight: '40px' }}>
        Site Map
      </FooterLink>
      <FacebookIcon sx={{ color: '#89949E', marginLeft: '10px', cursor: 'pointer' }} />
      <TwitterIcon sx={{ color: '#89949E', marginLeft: '10px', cursor: 'pointer' }} />
      <LinkedInIcon sx={{ color: '#89949E', marginLeft: '10px', cursor: 'pointer' }} />
    </Paper>
  );
};

export default Footer;
