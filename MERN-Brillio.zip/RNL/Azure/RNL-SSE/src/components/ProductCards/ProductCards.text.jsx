import React from 'react';
import { render, screen } from '@testing-library/react';
import ProductCards from './index';

// test block
test('load Cards Component', () => {
  render(<ProductCards />);
});
