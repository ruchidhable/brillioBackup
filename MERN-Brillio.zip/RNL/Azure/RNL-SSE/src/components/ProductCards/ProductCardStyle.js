import { CardMedia } from '@mui/material';
import { styled } from '@mui/material/styles';

export const ProductCardMedia = styled(CardMedia)(() => ({
  width: 700,
  height: 207,
  background: '#D8D8D8',
  display: 'flex',
  flexDirection: 'column',
}));
