import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Alert from './index';

// test block
test('render Alert Success Message', () => {
  expect('Success Message').toMatch(/ss/);
});
