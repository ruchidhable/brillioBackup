import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Divider from '@mui/material/Divider';
import {
  StatLabels,
  OverviewLabels,
  PercentMain,
  PercentSub,
  PlusSymbol,
} from '../../pages/Home/Overview/OverviewStyles';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';

const OverviewMetricDisplay = () => {
  return (
    <>
      <Paper
        sx={{
          height: '120px',
          width: '580px',
          borderRadius: '3px',
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
        }}
      >
        <Grid
          container
          direction="row"
          sx={{
            paddingTop: '30px',
            paddingLeft: '28px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <Grid item direction="column">
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain>3%</PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol sx={{ color: '#028340' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Student Success Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain sx={{ color: '#002E5C' }}>5%</PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol sx={{ color: '#028340' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Student Success Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                2%
              </PercentMain>
              <ArrowDropUpIcon
                sx={{ cursor: 'pointer', color: ' #C73A32', transform: 'rotate(-180deg)' }}
              />
              <PlusSymbol sx={{ color: '#C73A32' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#C73A32',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Student Success Stat</StatLabels>
            </Grid>
          </Grid>
        </Grid>
      </Paper>

      <OverviewLabels sx={{ paddingTop: '25px', paddingBottom: '10px' }}>
        FUNDRAISING SNAPSHOT
      </OverviewLabels>

      <Paper
        sx={{
          height: '120px',
          width: '580px',
          borderRadius: '3px',
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
        }}
      >
        <Grid
          container
          direction="row"
          sx={{ paddingTop: '30px', paddingLeft: '28px', display: 'flex', alignItems: 'center' }}
        >
          <Grid item direction="column">
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain>6%</PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol sx={{ color: '#028340' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Fundraising Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                2%
              </PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol sx={{ color: '#028340' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Fundraising Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                2%
              </PercentMain>
              <ArrowDropUpIcon
                sx={{ cursor: 'pointer', color: ' #C73A32', transform: 'rotate(-180deg)' }}
              />
              <PlusSymbol sx={{ color: '#C73A32' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#C73A32',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Fundraising Stat</StatLabels>
            </Grid>
          </Grid>
        </Grid>
      </Paper>

      <OverviewLabels sx={{ paddingTop: '25px', paddingBottom: '10px' }}>
        ENGAGEMENT SNAPSHOT
      </OverviewLabels>
      <Paper
        sx={{
          height: '120px',
          width: '580px',
          borderRadius: '3px',
          backgroundColor: '#FFFFFF',
          boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
        }}
      >
        <Grid
          container
          direction="row"
          sx={{ paddingTop: '30px', paddingLeft: '28px', display: 'flex', alignItems: 'center' }}
        >
          <Grid item direction="column">
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                6%
              </PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol sx={{ color: '#028340' }} variant="body2">
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Engagement Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                2%
              </PercentMain>
              <ArrowDropUpIcon sx={{ cursor: 'pointer', color: '#028340' }} />
              <PlusSymbol
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#028340',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Engagement Stat</StatLabels>
            </Grid>
          </Grid>
          <Divider
            sx={{
              boxSizing: 'border-box',
              height: '68px',
              width: '2px',
              borderLeft: '2px solid #E9EAEB',
            }}
            variant="middle"
            flexItem
          />
          <Grid item direction="column" sx={{ paddingLeft: '20px' }}>
            <Grid item direction="row" sx={{ display: 'flex', alignItems: 'center' }}>
              <PercentMain
                sx={{
                  color: '#002E5C',
                }}
              >
                2%
              </PercentMain>
              <ArrowDropUpIcon
                sx={{ cursor: 'pointer', color: ' #C73A32', transform: 'rotate(-180deg)' }}
              />
              <PlusSymbol
                sx={{
                  color: '#C73A32',
                }}
                variant="body2"
              >
                +
              </PlusSymbol>
              <PercentSub
                sx={{
                  color: '#C73A32',
                }}
                variant="body2"
              >
                10%
              </PercentSub>
            </Grid>
            <Grid item>
              <StatLabels>Engagement Stat</StatLabels>
            </Grid>
          </Grid>
        </Grid>
      </Paper>
    </>
  );
};

export default OverviewMetricDisplay;
