import api from '../utils/axios';
import { DEV_SUBSCRIBE_PRODUCT } from '../utils/Constants';

const getSubscribedProducts = () => {
  return api.get(DEV_SUBSCRIBE_PRODUCT, {}, { email: 'Sunil.Hirole@ruffalonl.com' });
};

const SubscribedProductService = {
  getSubscribedProducts,
};
export default SubscribedProductService;
