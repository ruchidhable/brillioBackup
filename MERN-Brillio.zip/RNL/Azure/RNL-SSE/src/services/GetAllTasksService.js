/* eslint-disable max-len */
import api from '../utils/axios';
import { GET_ALL_TASKS } from '../utils/Constants';
import { PERSONALIZATION } from '../MockData/Labels';

const getAllTasks = () => api.get(GET_ALL_TASKS, {}, { email: PERSONALIZATION.EMAIL });

const getAllTasksService = {
  getAllTasks,
};
export default getAllTasksService;
