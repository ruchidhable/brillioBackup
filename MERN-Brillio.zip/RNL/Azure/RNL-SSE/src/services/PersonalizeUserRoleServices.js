/* eslint-disable max-len */
import api from '../utils/axios';
import { SAVE_USER_ROLE } from '../utils/Constants';

const saveUserRoleDetails = (body) => api.post(SAVE_USER_ROLE, body, {}, {});

const PersonalizeUserRoleService = {
  saveUserRoleDetails,
};
export default PersonalizeUserRoleService;
