/* eslint-disable max-len */
import api from '../utils/axios';
import { PERSONALIZATION } from '../MockData/Labels';
import { GET_USER_ROLE , UPDATE_USER_ROLE } from '../utils/Constants';

const getUserRole = () => api.get(GET_USER_ROLE, {}, { email: PERSONALIZATION.EMAIL });

const updateUserRole = (body) => api.put(UPDATE_USER_ROLE, body, {}, {});

const GetPersonalizeUserRoleService = {
  getUserRole,
  updateUserRole,
};
export default GetPersonalizeUserRoleService;
