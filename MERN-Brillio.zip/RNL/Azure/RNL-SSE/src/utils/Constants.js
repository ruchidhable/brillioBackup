export const DEV_SUBSCRIBE_PRODUCT = '/dev/SubscribedProductList';
export const SAVE_USER_ROLE = '/save/saveUserDetails';
export const GET_PRODUCT_CARDS = '/IntegrationServiceDEV/productCategory';
export const GET_USER_ROLE = '/role/getUserRoleByEmail';
export const UPDATE_USER_ROLE = '/api/updateUserDetails';
export const GET_ALL_TASKS = '/task/getAllTask';