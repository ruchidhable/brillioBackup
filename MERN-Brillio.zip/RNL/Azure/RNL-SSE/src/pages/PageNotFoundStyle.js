/* eslint-disable import/prefer-default-export */
import { styled } from '@mui/material/styles';
import Typography from '@mui/material/Typography';

export const PageNotFoundContent = styled(Typography)(() => ({
  fontFamily: 'Helvetica Neue Regular',
  fontSize: '21px',
}));
