import { styled } from '@mui/material/styles';
import Typography from '@mui/material/Typography';

export const AllTaskLabel = styled(Typography)(() => ({
  height: '31px',
  width: '343px',
  color: '#002E5C',
  fontFamily: 'Helvetica',
  fontSize: '24px',
  fontWeight: 'bold',
  letterSpacing: 0,
  lineHeight: '20px',
}));

export const SortByLabel = styled(Typography)(() => ({
  marginLeft: '-350px',
  marginTop: '-26px',
  marginRight: '21px',
  color: '#2D3136',
  fontFamily: 'Helvetica',
  fontSize: '16px',
  fontWeight: 'bold',
  letterSpacing: '0px',
  lineHeight: '32px',
  textAlign: 'right',
}));

export const TableContainerLayout = styled(Typography)(() => ({
  '&.MuiTableContainer-root': {
    boxShadow: '0 ! important',
  },
}));

export const TaskHeaderLabel = styled(Typography)(() => ({
  height: '24px',
  width: '136px',
  color: '#696F76',
  fontFamily: 'Helvetica Neue Regular',
  fontSize: '14px',
  letterSpacing: '0.25px',
  lineHeight: '16px',
  '&.MuiTypography-root': {
    fontFamily: 'inherit',
  },
}));
