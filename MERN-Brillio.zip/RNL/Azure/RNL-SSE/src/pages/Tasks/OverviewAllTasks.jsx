/* eslint-disable import/no-named-as-default */
import React, { useState, useEffect, useCallback } from 'react';
import Pagination from '@mui/material/Pagination';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { MenuItem, Select, ListItem, ListItemText, Divider } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import { useDispatch, useSelector } from 'react-redux';
import TableRow from '@mui/material/TableRow';
import { getAllTasksDetails } from '../../slices/getAllTasksSlice';

import {
  SortByLabel,
  AllTaskLabel,
  TableContainerLayout,
  TaskHeaderLabel,
} from './OverviewAllTasksStyles';

function OverviewAllTasks() {
  const [tasksData, setTasksData] = useState([]);
  const [sortType, setSortType] = useState('taskDescription');
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const initialData = useSelector((state) => state.tasks);
  const handleChange = (event, newPage) => {
    setPage(newPage);
  };

  const dispatch = useDispatch();
  const initFetch = useCallback(() => {
    dispatch(getAllTasksDetails()).then((response) => {
      setTasksData(response.payload);
    });
  }, [dispatch]);

  useEffect(() => {
    initFetch();
  }, [initFetch]);

  useEffect(() => {
    const sortArray = (type) => {
      const types = {
        taskDescription: 'taskDescription',
        taskType: 'taskType',
        taskCategory: 'taskCategory',
        taskDate: 'taskDate',
      };
      const sortProperty = types[type];
      const sorted = [...tasksData].sort((a, b) => (a[sortProperty] < b[sortProperty] ? -1 : 1));
      setTasksData(sorted);
    };
    sortArray(sortType);
  }, [sortType]);

  const menuData = [
    { label: 'Task', value: 'all' },
    { label: 'Type', value: 'type' },
    { label: 'Due Date', value: 'date' },
    { label: 'Category', value: 'category' },
  ];
  const totalCount = Math.ceil(tasksData.length / rowsPerPage) - 1;

  return (
    <Box
      sx={{
        flexShrink: 0,
        paddingBottom: '20px',
        marginTop: '20px',
        backgroundColor: '#F8F9FA',
        overflow: 'hidden',
      }}
    >
      <Grid
        container
        sx={{
          width: 'auto',
          alignItem: 'center',
          backgroundColor: '#FFFFFF',
          paddingTop: '18px',
        }}
      >
        <Grid item>
          <ListItem>
            <ListItemText sx={{ color: '#0F6DBE', paddingLeft: '5px' }}>
              <HomeIcon sx={{ fontSize: 21, mt: -1 }} />
            </ListItemText>
          </ListItem>
        </Grid>
        <Divider
          orientation="vertical"
          sx={{
            height: 13,
            border: 0.1,
            color: '#696F76',
            mt: 1.7,
          }}
        />
        <Grid item>
          <ListItem>
            <ListItemText>
              <TaskHeaderLabel>{initialData.taskLabel}</TaskHeaderLabel>
            </ListItemText>
          </ListItem>
        </Grid>
        <Grid item />
      </Grid>
      <Grid
        container
        direction="row"
        sx={{ paddingLeft: '25px', backgroundColor: '#FFFFFF', paddingBottom: '10px' }}
      >
        <Grid item display="flex" justifyContent="flex-start" alignItems="center">
          <AllTaskLabel>{initialData.taskHeader}</AllTaskLabel>
        </Grid>
        <Grid
          item
          display="flex"
          justifyContent="flex-end"
          alignItems="center"
          sx={{ paddingLeft: '813px' }}
        >
          <SortByLabel>Sort By </SortByLabel>
          <Select
            sx={{ width: 144, height: 41, background: '#FFFFFF', marginTop: '-30px' }}
            onChange={(e) => setSortType(e.target.value)}
          >
            <MenuItem value="taskDescription">All</MenuItem>
            <MenuItem value="taskType">Type</MenuItem>
            <MenuItem value="taskCategory">Category</MenuItem>
            <MenuItem value="taskDate">Date</MenuItem>
          </Select>
        </Grid>
      </Grid>
      <Divider
        sx={{
          borderLeft: 0,
          borderTop: 0,
          borderRight: 0,
          borderBotton: '1px solid #696F76',
        }}
      />
      <TableContainerLayout
        sx={{
          maxHeight: '400px',
          height: '1000px',
          width: '1160px',
          borderLeft: '1px solid #EBECED',
          borderTop: '1px solid #EBECED',
          borderRight: '1px solid #EBECED',
          backgroundColor: 'lightblue',
          backgroundColor: '#FFFFFF',
          marginTop: '20px',
          marginLeft: '20px',
          borderBottom: '1px solid #FFFFFF',
        }}
      >
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              {menuData.map((menu) => (
                <TableCell key={menu.value} sx={{ fontWeight: 'bold' }}>
                  {menu.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody sx={{ backgroundColor: '#FFFFFF' }}>
            {(rowsPerPage > 0
              ? tasksData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              : tasksData
            ).map((rowData) => (
              <TableRow key={rowData.id} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell align="left" style={{ minWidth: 25, maxWidth: 180 }}>
                  {rowData.taskDescription}
                </TableCell>
                <TableCell
                  style={{ minWidth: 25, maxWidth: 100 }}
                  sx={{ color: '#0071CE', fontWeight: 'bold' }}
                  align="left"
                >
                  {rowData.taskType}
                </TableCell>
                <TableCell style={{ minWidth: 25, maxWidth: 90 }} align="left">
                  {rowData.taskDate}
                </TableCell>
                <TableCell style={{ minWidth: 25, maxWidth: 90 }} align="left">
                  {rowData.taskCategory}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainerLayout>
      <Pagination
        sx={{
          display: 'flex',
          justifyContent: 'center',
          backgroundColor: '#FFFFFF',
          marginLeft: '20px',
          borderLeft: '1px solid #EBECED',
          borderRight: '1px solid #EBECED',
        }}
        count={totalCount}
        rowsPerPage={5}
        page={page}
        defaultPage={1}
        onChange={handleChange}
      />
    </Box>
  );
}

export default OverviewAllTasks;
