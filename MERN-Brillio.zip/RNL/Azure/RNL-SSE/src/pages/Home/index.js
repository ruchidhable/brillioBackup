import Welcome from '../../components/Navigation/Welcome';
import Carousel from '../../components/Carousel';

export default function Home() {
  return (
    <>
      <Welcome />
      <Carousel />
    </>
  );
}
