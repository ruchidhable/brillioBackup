/* eslint-disable no-dupe-keys */
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import SquareIcon from '@mui/icons-material/Square';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { CardContent, Card } from '@mui/material';
import CachedIcon from '@mui/icons-material/Cached';
import PeopleIcon from '@mui/icons-material/People';
import InfoIcon from '@mui/icons-material/Info';
import SchoolIcon from '@mui/icons-material/School';
import PsychologyIcon from '@mui/icons-material/Psychology';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import OverviewMetricDisplay from '../../../components/Metrics/OverviewMetricDisplay';
import {
  OverviewLabels,
  TaskDetails,
  TaskLink,
  LaunchLabels,
  LaunchDetails,
  LaunchLink,
} from './OverviewStyles';
import { OVERVIEW } from '../../../MockData/Labels';
import { hideWelcomeHeader } from '../../../slices/tasksSlice';
import Header from '../../../components/Header';

export const TaskTemplate = styled(Paper)(({ theme }) => ({
  backgroundColor: '#FFFFFF',
  padding: theme.spacing(1),
  display: 'flex',
  color: theme.palette.text.secondary,
  borderLeft: 'solid 5px #0071CE',
  borderRadius: '0 3px 3px 0',
  height: '48px',
  width: '1150px',
  boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
}));

function Overview() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const toggleTaskValue = useSelector((state) => state.tasks.toggleTaskValue);

  const handleAllTasks = () => {
    dispatch(hideWelcomeHeader());
    navigate('/tasks');
  };

  return (
    <>
      <Header />
      <Box
        sx={{
          height: 'auto',
          paddingLeft: '22px',
          paddingRight: '22px',
          paddingBottom: '25px',
          width: '1193px',
          border: '1px solid #EBECED',
          backgroundColor: '#F8F9FA',
        }}
      >
        <Grid container direction="row">
          <OverviewLabels
            sx={{
              paddingTop: '20px',
              paddingBottom: '20px',
              paddingRight: '335px',
              display: 'flex',
            }}
          >
            {OVERVIEW.UPCOMING_TASKS}
          </OverviewLabels>
          <TaskLink
            underline="none"
            onClick={handleAllTasks}
            sx={{
              display: 'flex',
              cursor: 'pointer',
              alignItems: 'center',
              paddingLeft: '613px',
            }}
          >
            {OVERVIEW.VIEW_ALL}
            <NavigateNextIcon />
          </TaskLink>
        </Grid>
        <Stack spacing={1}>
          <TaskTemplate sx={{ width: '100%' }}>
            {' '}
            <SquareIcon sx={{ height: '32px', width: '32px', color: '#D8D8D8' }} />
            <TaskDetails>
              Upload new student data before Spring quarter starts (Due 2/28)
            </TaskDetails>
            <TaskLink
              underline="none"
              sx={{
                display: 'flex',
                cursor: 'pointer',
                alignItems: 'center',
                paddingLeft: '553px',
              }}
            >
              {OVERVIEW.UPLOAD_DATA}
              <NavigateNextIcon />
            </TaskLink>
          </TaskTemplate>
          <TaskTemplate sx={{ width: '100%' }}>
            {' '}
            <SquareIcon sx={{ height: '32px', width: '32px', color: '#D8D8D8' }} />
            <TaskDetails>You started a campaign 3 days ago. Ready to launch?</TaskDetails>
            <TaskLink
              underline="none"
              sx={{
                display: 'flex',
                cursor: 'pointer',
                alignItems: 'center',
                justifyContent: 'flex-end',
                paddingLeft: '613px',
              }}
            >
              {OVERVIEW.LAUNCH_WMJ}
              <NavigateNextIcon />
            </TaskLink>
          </TaskTemplate>
        </Stack>
        <Grid container spacing={7} direction="row" display="flex" alignItems="center">
          <Grid item xs={6}>
            <OverviewLabels sx={{ paddingTop: '25px', paddingBottom: '10px' }}>
              STUDENT SUCCESS
            </OverviewLabels>
            <OverviewMetricDisplay />
          </Grid>
          <Grid item xs={6}>
            <OverviewLabels sx={{ paddingTop: '25px', paddingBottom: '10px' }}>
              ENROLLMENT OVERVIEW
            </OverviewLabels>
            <Paper
              sx={{
                height: '465px',
                width: '550px',
                borderRadius: '3px',
                paddingTop: '10px',
                backgroundColor: '#FFFFFF',
                boxShadow: '0 0 3px 0 rgba(0,0,0,0.15)',
              }}
            />
          </Grid>
        </Grid>

        <OverviewLabels sx={{ paddingTop: '25px', paddingBottom: '10px' }}>
          {OVERVIEW.LAUNCH_AREAS}
        </OverviewLabels>
        <Grid container direction="row" display="flex" spacing={2}>
          <Grid item>
            <Card
              sx={{
                height: '189px',
                width: '371px',
              }}
            >
              <CardContent>
                <Grid item display="flex" alignItems="center">
                  <CachedIcon sx={{ color: '#89949E', width: '30px', height: '30px' }} />
                  <LaunchLabels sx={{ paddingLeft: '10px', paddingTop: '2px' }}>
                    Sync Center
                  </LaunchLabels>
                </Grid>
                <LaunchDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Lorem ipsum dolor sit amet consecttur adjklfsdf </li>
                    <li>Sed do eiusmod tempore incsdar ut labore et dolore magna aligque</li>
                  </ul>
                </LaunchDetails>
                <Grid container direction="row">
                  <LaunchLink
                    underline="none"
                    sx={{
                      marginBottom: '5px',
                      cursor: 'pointer',
                      display: 'flex',
                      cursor: 'pointer',
                      alignItems: 'center',
                      paddingLeft: '171px',
                    }}
                  >
                    {OVERVIEW.LAUNCH_SYNC_CENTER} <NavigateNextIcon />
                  </LaunchLink>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item>
            <Card
              sx={{
                height: '189px',
                width: '372px',
              }}
            >
              <CardContent>
                <Grid item display="flex" alignItems="center">
                  <InfoIcon sx={{ color: '#89949E', width: '30px', height: '30px' }} />
                  <LaunchLabels sx={{ paddingLeft: '10px', paddingTop: '2px' }}>
                    Service Now
                  </LaunchLabels>
                </Grid>
                <LaunchDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Lorem ipsum dolor sit amet consecttur adjklfsdf </li>
                    <li>Sed do eiusmod tempore incsdar ut labore et dolore magna aligque</li>
                  </ul>
                </LaunchDetails>
                <Grid container direction="row">
                  <LaunchLink
                    underline="none"
                    sx={{
                      marginBottom: '5px',
                      cursor: 'pointer',
                      display: 'flex',
                      cursor: 'pointer',
                      alignItems: 'center',
                      paddingLeft: '171px',
                    }}
                  >
                    {OVERVIEW.LAUNCH_SERVICE_NOW} <NavigateNextIcon />
                  </LaunchLink>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item>
            <Card
              sx={{
                height: '189px',
                width: '372px',
              }}
            >
              <CardContent>
                <Grid item display="flex" alignItems="center">
                  <SchoolIcon sx={{ color: '#89949E', width: '30px', height: '30px' }} />
                  <LaunchLabels sx={{ paddingLeft: '10px', paddingTop: '2px' }}>
                    Knowledge Center
                  </LaunchLabels>
                </Grid>
                <LaunchDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Lorem ipsum dolor sit amet consecttur adjklfsdf </li>
                    <li>Sed do eiusmod tempore incsdar ut labore et dolore magna aligque</li>
                  </ul>
                </LaunchDetails>
                <Grid container direction="row">
                  <LaunchLink
                    underline="none"
                    sx={{
                      marginBottom: '5px',
                      cursor: 'pointer',
                      display: 'flex',
                      cursor: 'pointer',
                      alignItems: 'center',
                      paddingLeft: '131px',
                    }}
                  >
                    {OVERVIEW.LAUNCH_KNOWLEDGE_CENTER} <NavigateNextIcon />
                  </LaunchLink>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item>
            <Card
              sx={{
                height: '189px',
                width: '372px',
              }}
            >
              <CardContent>
                <Grid item display="flex" alignItems="center">
                  <PsychologyIcon sx={{ color: '#89949E', width: '30px', height: '30px' }} />
                  <LaunchLabels sx={{ paddingLeft: '10px', paddingTop: '2px' }}>
                    RNL Smart View
                  </LaunchLabels>
                </Grid>
                <LaunchDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Lorem ipsum dolor sit amet consecttur adjklfsdf </li>
                    <li>Sed do eiusmod tempore incsdar ut labore et dolore magna aligque</li>
                  </ul>
                </LaunchDetails>
                <Grid container direction="row">
                  <LaunchLink
                    underline="none"
                    sx={{
                      marginBottom: '5px',
                      cursor: 'pointer',
                      display: 'flex',
                      cursor: 'pointer',
                      alignItems: 'center',
                      paddingLeft: '146px',
                    }}
                  >
                    {OVERVIEW.LAUNCH_RNL_SMART_VIEW} <NavigateNextIcon />
                  </LaunchLink>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item>
            <Card
              sx={{
                height: '189px',
                width: '372px',
              }}
            >
              <CardContent>
                <Grid item display="flex" alignItems="center">
                  <PeopleIcon sx={{ color: '#89949E', width: '30px', height: '30px' }} />
                  <LaunchLabels sx={{ paddingLeft: '10px', paddingTop: '2px' }}>
                    Collaboration Center
                  </LaunchLabels>
                </Grid>
                <LaunchDetails variant="body2" color="text.secondary">
                  <ul>
                    <li>Lorem ipsum dolor sit amet consecttur adjklfsdf </li>
                    <li>Sed do eiusmod tempore incsdar ut labore et dolore magna aligque</li>
                  </ul>
                </LaunchDetails>
                <Grid container direction="row">
                  <LaunchLink
                    underline="none"
                    sx={{
                      marginBottom: '5px',
                      cursor: 'pointer',
                      display: 'flex',
                      cursor: 'pointer',
                      alignItems: 'center',
                      paddingLeft: '116px',
                    }}
                  >
                    {OVERVIEW.LAUNCH_COLLABORATION_CENTER} <NavigateNextIcon />
                  </LaunchLink>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </>
  );
}

export default Overview;
