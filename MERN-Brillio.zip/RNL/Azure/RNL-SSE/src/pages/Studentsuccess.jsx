/* eslint-disable max-len */
/* eslint-disable camelcase */
import Carousel from '../components/Carousel';
import ProductCards from '../components/ProductCards';
import Header from '../components/Header';

const productCardData = {
  id: 'StudentSuccess',
};

function Studentsuccess() {
  return (
    <>
      <Header />
      <Carousel />
      <ProductCards data={productCardData} />
    </>
  );
}
export default Studentsuccess;
