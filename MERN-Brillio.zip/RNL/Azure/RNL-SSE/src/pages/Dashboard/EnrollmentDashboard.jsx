import React from 'react';
import { useNavigate } from 'react-router-dom';
import Link from '@mui/material/Link';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const EnrollmentDashboard = () => {
  const navigate = useNavigate();
  const handleEnrollmentProducts = () => {
    navigate('/enrollment');
  };

  return (
    <>
      <h1>Enrollment Dashboard</h1>
      <Link
        underline="none"
        component="button"
        onClick={handleEnrollmentProducts}
        sx={{ cursor: 'pointer', display: 'flex', alignItems: 'center', fontWeight: 'bold' }}
      >
        View all enrollment products <NavigateNextIcon />
      </Link>
    </>
  );
};

export default EnrollmentDashboard;
