import React from 'react';
import { useNavigate } from 'react-router-dom';
import Link from '@mui/material/Link';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const FundraisingDashboard = () => {
  const navigate = useNavigate();
  const handleFundraisingProducts = () => {
    navigate('/fundraising');
  };
  return (
    <>
      <h1>Fundraising Dashboard</h1>
      <Link
        underline="none"
        component="button"
        onClick={handleFundraisingProducts}
        sx={{ cursor: 'pointer', display: 'flex', alignItems: 'center', fontWeight: 'bold' }}
      >
        View all fundraising products <NavigateNextIcon />
      </Link>
    </>
  );
};

export default FundraisingDashboard;
