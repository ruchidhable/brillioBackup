import React from 'react';
import { useNavigate } from 'react-router-dom';
import Link from '@mui/material/Link';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const StudentSuccessDashboard = () => {
  const navigate = useNavigate();
  const handleStudentSuccessProducts = () => {
    navigate('/student-success');
  };
  return (
    <>
      <h1>StudentSuccess Dashboard</h1>
      <Link
        underline="none"
        component="button"
        onClick={handleStudentSuccessProducts}
        sx={{ cursor: 'pointer', display: 'flex', alignItems: 'center', fontWeight: 'bold' }}
      >
        View all student success products <NavigateNextIcon />
      </Link>
    </>
  );
};

export default StudentSuccessDashboard;
