import Layout from './components/Layout';
import Routes from './routes/RouteComponent';

function App() {
  return (
    <Routes>
      <Layout />
    </Routes>
  );
}

export default App;
