import logo from "./logo.svg";
import "./App.css";
import PowerBIAccessToken from "./PowerBIAccessToken";

function App() {
  return (
    <div className="App">
      <PowerBIAccessToken />
    </div>
  );
}

export default App;
