import Layout from "./components/Layout/Layout";
import Routes from "./routes/Routes";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Layout>
        <Routes />
      </Layout>
    </div>
  );
}

export default App;
