//Importing pages
import { Switch, Route } from "react-router-dom";
import Dashboard from "../pages/Dashboard/Dashboard";
import Login from "../pages/Users/Login";
import SinglePost from "../pages/SinglePost/SinglePost";
import PostForm from "../pages/Posts/PostForm";
import Registration from "../pages/Users/Registration";

//Defining Routes
const Routes = () => {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/posts/:id" component={SinglePost} />
      <Route path="/add-post" component={PostForm} />
      <Route path="/" exact component={Dashboard} />
      <Route path="/register" component={Registration}></Route>
    </Switch>
  );
};

export default Routes;
