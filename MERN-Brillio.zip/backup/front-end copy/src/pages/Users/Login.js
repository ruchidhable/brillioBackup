import React from "react";
import axios from "axios";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import Dashbord from "../Dashboard/Dashboard";
import "./Login.css";

const Login = () => {
  const [userEmail, setUserEmail] = useState();
  const [password, setPassword] = useState();

  const history = useHistory();

  const handleChange1 = (e) => {
    setUserEmail(e.target.value);
  };

  const handleChange2 = (e) => {
    setPassword(e.target.value);
  };

  const gotoDashbord = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:8010/login", {
        userEmail: document.loginData.userEmail.value,
        password: document.loginData.password.value,
      })
      .then((response) => {
        var obj1 = response.data;
        console.log(response.data);
        if (obj1.data.length == 1) {
          localStorage.setItem("accessToken", obj1.accessToken);
          history.push("/");
        } else {
          alert("Invalid Credentials...");
          window.location.reload();
        }
      });
  };

  return (
    <>
      {/* //login Form */}
      <div className="container-fluid ps-md-1">
        <div className="row g-0">
          <div className="d-none d-md-flex col-md-0 col-lg-4 bg-image"></div>
          <div className="col-md-8 col-lg-5">
            <div className="login d-flex align-items-center py-5">
              <div className="container">
                <div className="row">
                  <div className="col-md-8 col-lg-11 mx-auto">
                    <h3 className="login-heading mb-4">
                      &emsp;Welcome to BlogMan!
                    </h3>

                    <form name="loginData">
                      <div className="form-floating mb-3">
                        <label for="floatingInput">Email address</label>
                        <input
                          type="email"
                          name="email"
                          value={userEmail}
                          onChange={handleChange1}
                          class="form-control"
                          id="floatingInput"
                          placeholder="email@example.com"
                          required
                        />
                      </div>
                      <div className="form-floating mb-3">
                        <label for="floatingPassword">Password</label>
                        <input
                          type="password"
                          name="passowrd"
                          value={password}
                          onChange={handleChange2}
                          class="form-control"
                          id="floatingPassword"
                          placeholder="Password"
                          required
                        />
                      </div>

                      <br />
                      <div className="d-grid">
                        <button
                          className="btn btn-lg btn-primary btn-login text-uppercase fw-bold mb-2"
                          type="submit"
                        >
                          Sign in
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
