// JWT Authentication
function authHeader() {
  const accessToken = localStorage.getItem("accessToken");
  if (accessToken) {
    return { Authorization: "Bearer " + accessToken }; //Bearer ertergrh2344.efgfh.fhgf
  } else {
    return {};
  }
}

//remove token
function logout() {
  localStorage.removeItem("accessToken");
}
