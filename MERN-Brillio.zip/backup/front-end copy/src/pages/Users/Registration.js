import React from "react";
import axios from "axios";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import Login from "./Login";
import Dashboard from "../Dashboard/Dashboard";
import "./Register.css";

const Registration = () => {
  const [username, setUsername] = useState();
  const [useremail, setUseremail] = useState();
  const [usercity, setUsercity] = useState();
  const [userpassword, setUserpassword] = useState();
  const [userConfirmpassword, setUserconfirmpassword] = useState();

  const history = useHistory();
  const history1 = useHistory();

  const handlechange1 = (e) => {
    setUsername(e.target.value);
  };

  const handlechange2 = (e) => {
    setUseremail(e.target.value);
  };

  const handlechange3 = (e) => {
    setUsercity(e.target.value);
  };

  const handlechange4 = (e) => {
    setUserpassword(e.target.value);
  };

  const handlechange5 = (e) => {
    setUserconfirmpassword(e.target.value);
  };

  const gotologin = (e) => {
    e.preventDefault();
    // var obj1 = {
    //   username: username,
    //   useremail: useremail,
    //   usercity: usercity,
    //   userpassword: userpassword,
    //   userConfirmpassword: userConfirmpassword,
    // };

    // var cnt1 = 0;
    if (
      username == undefined ||
      useremail == undefined ||
      usercity == undefined ||
      userpassword == undefined ||
      userConfirmpassword == undefined
    ) {
      alert("Please provide all the fields");
      // window.document.location.reload();
      document.registerForm.username.focus();
      return;
    }
    var emailAt = useremail.indexOf("@");
    var emailAtDot = useremail.indexOf(".");
    if (emailAt < 1 || emailAtDot - emailAt < 2) {
      alert("Please provide valid Email Address");
      document.registerForm.useremail.focus();
      return;
    }

    if (userpassword != userConfirmpassword) {
      alert("Password should match to Confirm Password");
      // window.document.location.reload();
      document.registerForm.userpassword.focus();
      return;
    }
    axios
      .post("http://localhost:8010/register", {
        username: username,
        useremail: useremail,
        usercity: usercity,
        userpassword: userpassword,
        userType: 1,
      })
      .then((res) => {
        var obj2 = res.data;
        console.log(res.data);
        alert("User added successfully...");
        // window.location.reload();
        history.push("/login");
      })
      .catch(function (err) {
        console.log(err);
      });
  };
  const gotodashbord = (e) => {
    e.preventDefault();
    history1.push("/");
  };
  return (
    <>
      {/* //Registration form */}
      <div class="container-fluid ps-md-1">
        <div class="row g-0">
          <div class="d-none d-md-flex col-md-0 col-lg-4 bg-image"></div>
          <div class="col-md-8 col-lg-5">
            <div class="login d-flex align-items-center py-5">
              <div class="container">
                <div class="row">
                  <div class="col-md-8 col-lg-11 mx-auto">
                    <h3 class="login-heading mb-4">
                      &emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;<b>Register</b>
                    </h3>

                    <form name="registerForm">
                      <div class="form-floating mb-3">
                        <label for="floatingInput">Name</label>
                        <input
                          type="email"
                          name="userName"
                          value={userName}
                          onChange={handlechange1}
                          class="form-control"
                          id="floatingInput"
                          placeholder="User Name"
                          required
                        />
                      </div>
                      <div class="form-floating mb-3">
                        <label for="floatingInput">Email address</label>
                        <input
                          type="email"
                          name="userEmail"
                          value={userEmail}
                          onChange={handlechange2}
                          class="form-control"
                          id="floatingInput"
                          placeholder="email@example.com"
                          required
                        />
                      </div>

                      <div class="form-floating mb-3">
                        <label for="floatingPassword">Password</label>
                        <input
                          type="password"
                          name="password"
                          value={password}
                          onChange={handlechange3}
                          class="form-control"
                          id="floatingPassword"
                          placeholder="Password"
                          required
                        />
                      </div>
                      <div class="form-floating mb-3">
                        <label for="floatingPassword">Confirm Password</label>
                        <input
                          type="password"
                          name="userConfirmPassword"
                          value={userConfirmPassword}
                          onChange={handlechange4}
                          class="form-control"
                          id="floatingPassword"
                          placeholder="Confirm Password"
                          required
                        />
                      </div>

                      <br />
                      <div class="d-grid">
                        <button
                          class="btn btn-lg btn-primary btn-login text-uppercase fw-bold mb-2"
                          type="submit"
                        >
                          Register
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Registration;
