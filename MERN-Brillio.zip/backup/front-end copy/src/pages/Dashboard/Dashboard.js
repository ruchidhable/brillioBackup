//Importing prerequesities
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./Dashboard.css";
import _ from "lodash";

const pageSize = 10;

const Dashboard = () => {

  //Defining variables
  const [post, getPost] = useState("");
  const [paginatedPosts, setpaginatedPosts] = useState("");
  const [currentPage, setcurrentPage] = useState(1);

  // API url
  const url = "http://localhost:8020/";

  useEffect(() => {
    getAllPosts();
  }, []);

  const getAllPosts = () => {
    //Api call using axios to get all the posts.
    axios
      .get(url)
      .then((res) => {
        //Success - Getting Response
        const allPosts = res.data;
        getPost(allPosts);
        console.log(allPosts.length);
        setpaginatedPosts(_(res.data).slice(0).take(pageSize).value());
      })
      //Failure - Throwing Error
      .catch((err) => console.error(`Error: ${err}`));
  };

  const pageCount = post ? Math.ceil(post.length / pageSize) : 0;
  console.log(pageCount);
  if (pageCount === 0) {
    return null;
  }
  const pages = _.range(1, pageCount + 1);
  console.log(pages);

  //Pagination
  const pagination = (pageno) => {
    setcurrentPage(pageno);
    const startIndex = (pageno - 1) * pageSize;
    const paginatedPost = _(post).slice(startIndex).take(pageSize).value();
    setpaginatedPosts(paginatedPost);
  }

  return (
    <>
      <div className="header">
        <div className="headerTitles">
          <span className="headerTitleSm">Publish your passions, your way</span>
          <span className="headerTitleLg">IDEAS MATTERS</span>
        </div>
        <img
          className="headerImg"
          src="https://images.pexels.com/photos/1167355/pexels-photo-1167355.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          alt=""
        />
      </div>
      <div className="Home">
        {paginatedPosts &&
          paginatedPosts.map((items) => (
            <div className="post" key={items.id}>
              <Link to={`/posts/${items._id}`} target="_blank" className="link">
                <div className="postInfo">
                  <div className="postCats">
                    <i className="singlePostIcon far fa-user"></i>
                    <span className="postCat">
                      <b> Author: {items.createdBy.userName}</b>
                    </span>
                  </div>
                  <span className="postTitle">{items.title}</span>
                  <hr />
                  <span className="postDate">
                    <b>{new Date(items.createdAt).toDateString()}</b>
                  </span>
                  <p className="postDesc">{items.description}</p>
                </div>
              </Link>
            </div>
          ))}
      </div>
      <nav className="d-flex justify-content-center">
        <ul class="pagination">
          {pages.map((page) => (
            <li className={
              page === currentPage ? "page-item active" : "page-item"
            }
            >
              <p className="page-link" onClick={() => pagination(page)}>{page}</p>
            </li>
          ))
          }
        </ul>
      </nav>

    </>
  );
};
export default Dashboard;
