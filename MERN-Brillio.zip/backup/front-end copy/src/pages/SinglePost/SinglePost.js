//Importing prerequesities
import React, { useState, useEffect } from 'react';
import axios from "axios";
import { Link, useLocation } from "react-router-dom";
import "./SinglePost.css";


const SinglePost = () => {
  //Defining variables
  const location = useLocation()
  const path = location.pathname.split('/')[2];
  const [singlepost, getSinglePost] = useState('');

  useEffect(() => {
    getUserPost();
  }, [path]);

  const getUserPost = () => {
    //Api call using axios to get the particular post on the basis of Id.
    axios.get("http://localhost:8020/posts/" + path)
      .then((res) => {
        //Success - Getting Response
        const response = res.data;
        getSinglePost(response);
        console.log(response);
      })
      //Failure - Throwing Error
      .catch(err => console.error(`Error: ${err}`));
  }
  return (
    <>
      <div className="container">
        <div className="singlePost">
          {singlepost.title && <div className="singlePostWrapper">
            <h1 className="singlePostTitle">
              {singlepost.title}
              <div className="singlePostEdit">
                <i className="singlePostIcon far fa-edit"></i>
                <i className="singlePostIcon far fa-trash-alt"></i>
              </div>
            </h1>
            <div className="singlePostInfo">
              <span>
                <i className="singlePostIcon far fa-user"></i>
                <b className="singlePostAuthor">
                  Author:   {singlepost.createdBy.userName}
                </b>
              </span>
              <span>{new Date(singlepost.createdAt).toDateString()}</span>
            </div>
            <p className="singlePostDesc">
             <div dangerouslySetInnerHTML={{__html: singlepost.description}}></div>
            </p>
          </div>
          }
        </div>
      </div>
    </>
  )
}
export default SinglePost;
