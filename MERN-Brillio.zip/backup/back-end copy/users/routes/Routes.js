const express = require("express");
const Users = require("../models/User");
const jwt = require("jsonwebtoken");

const router = express.Router();

// Get all users
router.post("/login", function (req, res) {
  Users.find(
    { uname: req.body.username, password: req.body.password },
    function (err, data) {
      if (err) {
        console.log(err);
      } else {
        console.log(data);
        const user = { uname: req.body.username, password: req.body.password };
        const accesstoken = jwt.sign(user, "MySecretToken");
        res.json({ accessToken: accesstoken, data: data });
        // res.json(data);
        //   res.end(data);
      }
    }
  );
});
//add users
router.post("/register", async function (req, res) {
  console.log(req.body);
  var obj11 = new Users({
    uname: req.body.username,
    uemail: req.body.useremail,
    city: req.body.usercity,
    password: req.body.userpassword,
    utype: 1,
  });
  await obj11.save(function (err, data1) {
    if (err) {
      console.log(err);
    } else {
      console.log("data added:" + data1);
      res.end(data1.uname);
    }
  });
});
module.exports = router;
