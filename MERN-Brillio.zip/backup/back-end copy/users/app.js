// Import prerequisites
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const router = require("./routes/Routes");
const { POSTS_PORT: PORT, MONGO_URI: MONGO_URI } = require("./config/Config");

// Connect to MongoDB
mongoose
  .connect(MONGO_URI, { useNewUrlParser: true })
  .then(() => {
    console.log("Connected to MongoDB");

    const app = express();

    // Use CORS middleware
    app.use(cors());
    // Body parser
    app.use(express.json());

    // Define routes
    app.use("/", router);
    // app.use("/register", router);

    // Start server and listen for incoming requests
    app.listen(PORT, () =>
      console.log(`Users server is up and running on port: ${PORT}`)
    );
  })
  .catch((err) => {
    console.log("Could not connect to MongoDB", err);
  });
