//import prerequisites
var mongoose = require("mongoose");

//define user schema
UserSchema = new mongoose.Schema({
  uname: String,
  uemail: String,
  city: String,
  password: String,
  utype: Number,
});

module.exports = mongoose.model("Users", UserSchema, "user"); //model object
