module.exports = {
  POSTS_PORT: process.env.POSTS_PORT || 8010,
  MONGO_URI: process.env.MONGO_URI || "mongodb://localhost:27017/blogApp",
  SECRET_KEY: process.env.JWT_SECRET_KEY || "R2-D2",
};
