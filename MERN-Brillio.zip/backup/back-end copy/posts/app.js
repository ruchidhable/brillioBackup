// Import prerequisites
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const publicRoutes = require("./routes/publicRoutes");
const privateRoutes = require("./routes/privateRoutes");
const { POSTS_PORT: PORT, MONGO_URI: MONGO_URI } = require("./config/config");

// Connect to MongoDB
mongoose
  .connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");

    const app = express();

    // Use CORS middleware
    app.use(cors());
    // Body parser
    app.use(express.json());

    /*
    // Verify token
    const verifyToken = (req, res, next) => {
      const authToken = req.headers.authorization;
      const token = authToken ? authToken.split(" ")[1] : null;

      if (!token) return res.status(401).json({ message: "Invalid token." });

      jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err)
          return res
            .status(401)
            .json({
              message: "User unauthorized. Try logging-in again to continue.",
            });
        req.user = user;
        next();
      });
    };
    */

    // Remove later
    const sampleFunc = (req, res, next) => {
      req.user = { id: 1, name: "Suhail" };
      next();
    };

    // Define routes
    app.use("/", publicRoutes);
    app.use("/", sampleFunc, privateRoutes);

    // Start server and listen for incoming requests
    app.listen(PORT, () =>
      console.log(`Posts server is up and running on port: ${PORT}`)
    );
  })
  .catch((err) => {
    console.log("Could not connect to MongoDB", err);
  });
