// Import prerequisites
const mongoose = require("mongoose");

// Define post schema
const postSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    unique: true,
  },
  description: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  createdBy: {
    userId: {
      type: mongoose.ObjectId,
      required: true,
    },
    userName: {
      type: String,
      required: true,
    },
  },
});

module.exports = mongoose.model("Post", postSchema, "posts");
