// Import prerequisites
const app = require("./app");
const { PORT } = require("./config/config");

// Start server and listen for incoming requests
app.listen(PORT, () =>
  console.log(`Main server is up and running on port: ${PORT}`)
);
