const express = require("express");
const mongoose = require("mongoose");
const Post = require("../models/Post");

const router = express.Router();

/**
 * @api {post} /posts/ Insert post into posts.
 * @apiName InsertPost
 * @apiGroup Post
 *
 * @apiSuccess {JSON} {"message": "Post created successfully.", "data": {post}} Message and inserted record.
 * @apiFailure {JSON} {"message": "Bad request. Missing parameters."} Message.
 * @apiFailure {JSON} {"message": "Bad request. Internal server error. Failed insertion."} Message.
 */
router.post("/", async (req, res) => {
  try {
    // Extract content from body
    const { title, description } = req.body;
    if (title && description) {
      // Extracted user from token
      const { id: userId, name: userName } = req.user;

      // Insert post (with user) to posts
      const post = new Post({
        title,
        description,
        createdBy: {
          userId: mongoose.Types.ObjectId(userId),
          userName: userName,
        },
      });
      const createdPost = await post.save();

      // Success - Inserted
      if (createdPost) {
        return res.status(201).json({
          message: "Post created successfully.",
          data: { post: createdPost },
        });
      }
    }

    // Failure - Missing parameter(s)
    return res
      .status(400)
      .json({ message: "Bad request. Missing parameters." });
  } catch (error) {
    console.log("Post insertion error", error.message);
    // Failure - SQL Error
    return res.status(500).json({
      message: `Internal server error. Failed insertion. ${error.message}`,
    });
  }
});

/**
 * @api {put} /posts/:id Update post.
 * @apiName UpdatePost
 * @apiGroup Post
 *
 * @apiParam {String} id Posts unique ID.
 *
 * @apiSuccess {JSON} {"message": "Post updated successfully.", "data": {post}} Message and updated record.
 * @apiFailure {JSON} {"message": "Bad request. Missing parameters."} Message.
 * @apiFailure {JSON} {"message": "Bad request. Internal server error. Failed insertion."} Message.
 */
router.put("/:id", async (req, res) => {
  try {
    // Extract id from params
    const { id: postId } = req.params;
    // Extract content from body
    const { title, description } = req.body;
    if (postId && title && description) {
      // Find post (by id) and update values
      const updatedPost = await Post.findByIdAndUpdate(
        postId,
        {
          title,
          description,
        },
        { new: true }
      );

      // Success - Updated
      if (updatedPost) {
        return res.status(200).json({
          message: "Post updated successfully.",
          data: { post: updatedPost },
        });
      }
    }
  } catch (error) {
    console.log("Post updation error", error.message);
    // Failure - SQL Error
    return res.status(500).json({
      message: `Internal server error. Failed updation. ${error.message}`,
    });
  }
});

/**
 * @api {delete} /posts/:id Delete post.
 * @apiName DeletePost
 * @apiGroup Post
 *
 * @apiParam {String} id Posts unique ID.
 *
 * @apiSuccess {JSON} {"message": "Post deleted successfully."} Message and deleted record.
 * @apiFailure {JSON} {"message": "Bad request. Internal server error. Failed deletion."} Message.
 */
router.delete("/:id", async (req, res) => {
  try {
    // Extract id from params
    const { id: postId } = req.params;
    if (postId) {
      // Find post (by id) and delete
      const deletedPost = await Post.findByIdAndDelete(postId);

      // Success - Deleted
      if (deletedPost) {
        return res.status(200).json({
          message: "Post deleted successfully.",
          data: { post: deletedPost },
        });
      }
    }
  } catch (error) {
    console.log("Post deletion error", error.message);
    // Failure - SQL Error
    return res.status(500).json({
      message: `Internal server error. Failed deletion. ${error.message}`,
    });
  }
});

module.exports = router;
