// Importing libraries
const express = require("express");
const Post = require("../models/Post");

const router = express.Router();

// Get all posts
router.get("/", async (req, res) => {
  try {
    // Fetch query to find all the posts
    const post = await Post.find();
    // Success
    res.status(200).send(post);
  } catch (err) {
    // Failure
    res.status(500).send(err);
  }
});

// Get post
router.get("/:id", async (req, res) => {
  try {
    // Fetch query to view the particular post on the basis of Id
    const post = await Post.findById(req.params.id);
    // Success
    res.status(200).send(post);
  } catch (err) {
    // Failure
    res.status(500).send(err);
  }
});

module.exports = router;
