// Import prerequisites
var mongoose = require("mongoose");

// Define user schema
UserSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  type: Number,
});

module.exports = mongoose.model("User", UserSchema, "users");
