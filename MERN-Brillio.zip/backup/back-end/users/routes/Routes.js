// Importing libraries
const express = require("express");
const User = require("../models/User");
const jwt = require("jsonwebtoken");
const { SECRET_KEY } = require("../config/Config");

const router = express.Router();

// Login user
router.post("/login", function (req, res) {
  User.findOne(
    { email: req.body.email, password: req.body.password },
    function (err, user) {
      if (err) {
        res.status(500).send(err);
      } else {
        const userPayload = { id: user._id, name: user.name };
        const accessToken = jwt.sign(userPayload, SECRET_KEY);
        res.send({ accessToken: accessToken, user: user });
      }
    }
  );
});

// Register user
router.post("/register", function (req, res) {
  const user = new User({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password,
    type: 1,
  });

  user.save(function (err, newUser) {
    if (err) {
      res.status(500).send(err);
    } else {
      res.send(newUser);
    }
  });
});

module.exports = router;
