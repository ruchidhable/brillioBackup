// Import prerequisites
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const routes = require("./routes/Routes");
const { USERS_PORT: PORT, MONGO_URI: MONGO_URI } = require("./config/Config");

// Connect to MongoDB
mongoose
  .connect(MONGO_URI, { useNewUrlParser: true })
  .then(() => {
    console.log("Connected to MongoDB");

    const app = express();

    // Use CORS middleware
    app.use(cors());

    app.use(function (req, res, next) {
      res.header("Access-Control-Allow-Origin", "*");
      next();
    });

    // Body parser
    app.use(express.json());

    // Define routes
    app.use("/", routes);

    // Start server and listen for incoming requests
    app.listen(PORT, () =>
      console.log(`Users server is up and running on port: ${PORT}`)
    );
  })
  .catch((err) => {
    console.log("Could not connect to MongoDB", err);
  });
