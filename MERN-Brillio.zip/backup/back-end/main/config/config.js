module.exports = {
  PORT: process.env.MAIN_PORT || 8000,
  USERS_URL: `http://localhost:${process.env.USERS_PORT || 8010}`,
  POSTS_URL: `http://localhost:${process.env.POSTS_PORT || 8020}`,
};
