// Import prerequisites
const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const { USERS_URL, POSTS_URL } = require("./config/config");

const app = express();

// Create proxies for services
const users = createProxyMiddleware({
  target: USERS_URL,
  pathRewrite: { "/users": "/" },
});
const posts = createProxyMiddleware({
  target: POSTS_URL,
  pathRewrite: { "/posts": "/" },
});

// Use middlewares
app.use("/users", users);
app.use("/posts", posts);

// Test route - / GET
app.get("/", (req, res) => {
  res.status(200).json({ message: "Main server is up and running." });
});

module.exports = app;
