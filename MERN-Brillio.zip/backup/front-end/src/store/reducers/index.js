import { combineReducers } from "redux";

// Child reducers
import userReducer from "./userReducer";
import postReducer from "./postReducer";

// Parent reducer
const rootReducer = combineReducers({
  user: userReducer,
  post: postReducer,
});

export default rootReducer;
