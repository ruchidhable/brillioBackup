// Set initial data
const initialState = {
  posts: null,
  paginatedPosts: null,
  post: null,
};

// Reducer for post
const postReducer = (state = initialState, action) => {
  switch (action.type) {
    case "GET_POSTS":
      return {
        ...state,
        posts: action.payload.posts,
        paginatedPosts: action.payload.paginatedPosts,
      };
    case "SET_PAGINATION":
      return {
        ...state,
        paginatedPosts: action.payload.paginatedPosts,
      };
    case "GET_POST":
      return {
        ...state,
        post: action.payload.post,
      };
    case "DELETE_POST":
      const postsCopyForDelete = [...state.posts];
      const paginatedPostsCopyForDelete = [...state.paginatedPosts];
      const postIdForDeletion = action.payload.postId;

      const newPostsForDelete = postsCopyForDelete.filter(
        (post) => post._id !== postIdForDeletion
      );
      const newPaginatedPostsForDelete = paginatedPostsCopyForDelete.filter(
        (post) => post._id !== postIdForDeletion
      );

      return {
        ...state,
        posts: newPostsForDelete,
        paginatedPosts: newPaginatedPostsForDelete,
        post: null,
      };
    case "INSERT_POST":
      const postsCopyForInsert = [...state.posts];
      const paginatedPostsCopyForInsert = [...state.paginatedPosts];
      return {
        ...state,
        posts: [...postsCopyForInsert, action.payload.post],
        paginatedPosts: [...paginatedPostsCopyForInsert, action.payload.post],
      };
    case "UPDATE_POST":
      const postsCopyForUpdate = [...state.posts];
      const paginatedPostsCopyForUpdate = [...state.paginatedPosts];
      const postCopyForUpdate = action.payload.post;

      const postIndex = postsCopyForUpdate.findIndex(
        (post) => post._id === postCopyForUpdate._id
      );

      if (postIndex >= 0) {
        postsCopyForUpdate[postIndex] = postCopyForUpdate;
      }

      const paginatedPostsIndex = paginatedPostsCopyForUpdate.findIndex(
        (post) => post._id === postCopyForUpdate._id
      );

      if (paginatedPostsIndex >= 0) {
        paginatedPostsCopyForUpdate[paginatedPostsIndex] = postCopyForUpdate;
      }

      return {
        ...state,
        post: postCopyForUpdate,
        posts: postsCopyForUpdate,
        paginatedPosts: paginatedPostsCopyForUpdate,
      };
    default:
      return state;
  }
};

export default postReducer;
