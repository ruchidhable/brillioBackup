// Check local storage for user data
const dataStore = localStorage.getItem("data_store")
  ? JSON.parse(localStorage.getItem("data_store"))
  : {};

// Set initial data
const initialState = {
  isAuthenticated: dataStore.accessToken ? true : false,
  token: dataStore.accessToken ? dataStore.accessToken : null,
  loggedInUser: dataStore.userDetails ? dataStore.userDetails : {},
};

// Reducer for user
const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case "USER_LOGIN":
      localStorage.setItem(
        "data_store",
        JSON.stringify({
          accessToken: action.payload.token,
          userDetails: action.payload.user,
        })
      );
      return {
        isAuthenticated: true,
        token: action.payload.token,
        loggedInUser: action.payload.user,
      };
    case "USER_LOGOUT":
      localStorage.removeItem("data_store");
      return { isAuthenticated: false, token: null, loggedInUser: {} };
    default:
      return state;
  }
};

export default userReducer;
