import { useSelector, useDispatch } from "react-redux";
import { useHistory, NavLink } from "react-router-dom";

import { StickyContainer, Sticky } from "react-sticky";

import classes from "./Navigation.module.css";

const Navigation = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const isAuthenticated = useSelector((state) => state.user.isAuthenticated);

  const onClickLogOutHandler = () => {
    dispatch({ type: "USER_LOGOUT" });
    history.replace("/login");
  };

  return (
    <>
      <div
        id="sticky"
        className="d-flex flex-column flex-md-row text-white align-items-center p-3 px-md-4 mb-3 bg-primary border-bottom box-shadow"
      >
        <h5 className="my-0 mr-md-auto font-weight-medium ">BlogMan</h5>
        <nav className="my-2 my-md-0 mr-md-3">
          <NavLink
            className="p-2 text-white"
            activeClassName={classes.active}
            exact
            to="/"
          >
            Home
          </NavLink>
          {isAuthenticated ? (
            <>
              <NavLink
                className="p-2 text-white"
                activeClassName={classes.active}
                to="/add-post"
              >
                Add Post
              </NavLink>
              <span
                className={`${classes.logOut} p-2 text-white `}
                onClick={onClickLogOutHandler}
              >
                Sign Out
              </span>
            </>
          ) : (
            <>
              <NavLink
                className="p-2 text-white"
                activeClassName={classes.active}
                to="/login"
              >
                Login
              </NavLink>
              <NavLink
                className="p-2 text-white"
                activeClassName={classes.active}
                to="/register"
              >
                Register
              </NavLink>
            </>
          )}
        </nav>
      </div>
    </>
  );
};

export default Navigation;
