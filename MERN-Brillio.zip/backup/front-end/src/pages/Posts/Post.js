import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import axios from "axios";

import "./Post.css";

const Post = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const { token, loggedInUser } = useSelector((state) => state.user);
  const post = useSelector((state) => state.post.post);
  const path = location.pathname.split("/")[2];

  useEffect(() => {
    getUserPost();
  }, [path]);

  const getUserPost = () => {
    axios
      .get("http://localhost:8000/posts/" + path)
      .then((res) => {
        const post = res.data;
        dispatch({ type: "GET_POST", payload: { post: post } });
      })
      .catch((err) => console.error(`Error: ${err}`));
  };

  const onClickDeletePostHandler = async (postId) => {
    const result = window.confirm(`Are you sure you want to delete this post?`);
    if (result) {
      try {
        const response = await axios.delete(
          `http://localhost:8000/posts/${postId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        if (response.status === 200 && response.data) {
          dispatch({
            type: "DELETE_POST",
            payload: { postId: postId },
          });
          alert(response.data.message);
          history.replace("/");
        } else {
          alert("Sorry, something went wrong!");
          console.log("Error", response);
        }
      } catch (error) {
        alert("Sorry, something went wrong!");
        console.log("Error", error);
      }
    } else {
      return;
    }
  };
  return (
    <>
      <div className="container">
        <div className="posts">
          {post && (
            <div className="singlePostWrapper">
              <h1 className="singlePostTitle">
                {post.title}
                {post.createdBy.userId === loggedInUser._id && (
                  <div className="singlePostEdit">
                    <i
                      className="singlePostIcon far fa-edit"
                      onClick={() => history.push(`/edit-post/${post._id}`)}
                    ></i>
                    <i
                      className="singlePostIcon far fa-trash-alt"
                      onClick={() => onClickDeletePostHandler(post._id)}
                    ></i>
                  </div>
                )}
              </h1>
              <div className="singlePostInfo">
                <span>
                  <i className="singlePostIcon far fa-user"></i>
                  <b className="singlePostAuthor">
                    Author: {post.createdBy.userName}
                  </b>
                </span>
                <span>{new Date(post.createdAt).toDateString()}</span>
              </div>
              <p className="singlePostDesc">
                <div
                  dangerouslySetInnerHTML={{ __html: post.description }}
                ></div>
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
export default Post;
