import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { Editor } from "@tinymce/tinymce-react";
import axios from "axios";

const PostForm = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { postId } = useParams();
  const user = useSelector((state) => state.user);
  const post = useSelector((state) => state.post.post);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (postId && post && postId !== post._id) {
      getUserPost(postId);
    }
  }, [postId]);

  useEffect(() => {
    if (post && postId) {
      setTitle(post.title);
      setDescription(post.description);
    }
  }, [post]);

  const getUserPost = (postId) => {
    axios
      .get("http://localhost:8000/posts/" + postId)
      .then((res) => {
        const post = res.data;
        dispatch({ type: "GET_POST", payload: { post: post } });
      })
      .catch((err) => console.error(`Error: ${err}`));
  };

  const onSubmitPostFormHandler = async (e) => {
    try {
      e.preventDefault();
      if (postId) {
        const response = await axios.put(
          `http://localhost:8000/posts/${postId}`,
          {
            title,
            description,
          },
          {
            headers: {
              Authorization: `Bearer ${user.token}`,
            },
          }
        );
        if (response.status === 200 && response.data) {
          dispatch({
            type: "UPDATE_POST",
            payload: { post: response.data.data.post },
          });
          alert(response.data.message);
          history.replace("/");
        }
      } else {
        const response = await axios.post(
          "http://localhost:8000/posts",
          {
            title,
            description,
          },
          {
            headers: {
              Authorization: `Bearer ${user.token}`,
            },
          }
        );
        console.log(response);
        if (response.status === 201 && response.data) {
          dispatch({
            type: "INSERT_POST",
            payload: { post: response.data.data.post },
          });
          alert(response.data.message);
          history.replace("/");
        }
      }
    } catch (error) {
      alert("Sorry, something went wrong!");
      console.log("Error", error);
    }
  };

  return (
    <div className="container">
      <div className="py-5">
        <p className="lead mb-5 text-center">
          Write new exciting post every day using our revolutionary text editor.
          Powered by TinyMCE.
        </p>

        <div className="row">
          <div className="col-md-4 order-md-2 mb-4">
            <h4 className="d-flex justify-content-between align-items-center mb-3">
              <span className="text-muted">Post Details</span>
            </h4>
            <ul className="list-group mb-3">
              <li className="list-group-item d-flex justify-content-between bg-light">
                <div className="text-success">
                  <h6 className="my-0">Author</h6>
                </div>
                <span className="text-success">
                  {user && user.loggedInUser.name}
                </span>
              </li>
            </ul>
          </div>
          <div className="col-md-8 order-md-1">
            <h4 className="d-flex justify-content-between align-items-center mb-3">
              <span className="text-muted">Create Post</span>
            </h4>
            <form onSubmit={onSubmitPostFormHandler}>
              <div className="mb-3">
                <label htmlFor="title">Title</label>
                <input
                  type="text"
                  className="form-control"
                  id="title"
                  name="title"
                  placeholder="My Post Title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="title">Description</label>
                <Editor
                  id="description"
                  name="description"
                  value={description}
                  onEditorChange={(e) => setDescription(e)}
                  required
                  init={{
                    height: 250,
                    menubar: false,
                    plugins: [
                      "advlist autolink lists link image charmap print preview anchor",
                      "searchreplace visualblocks code fullscreen",
                      "insertdatetime media table paste code help wordcount",
                    ],
                    toolbar:
                      "undo redo | formatselect | " +
                      "bold italic backcolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                  }}
                />
              </div>

              <hr className="mb-4" />
              <button
                className="btn btn-primary btn-lg btn-block"
                type="submit"
                disabled={!title || !description}
              >
                Save Post
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostForm;
