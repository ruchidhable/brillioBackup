import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import axios from "axios";
import _ from "lodash";

import "./Posts.css";

const pageSize = 10;

const Posts = () => {
  const dispatch = useDispatch();
  const { posts, paginatedPosts } = useSelector((state) => state.post);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    if (!posts) {
      getAllPosts();
    }
  }, [posts]);

  const getAllPosts = () => {
    const url = "http://localhost:8000/posts";
    axios
      .get(url)
      .then((res) => {
        const allPosts = res.data;
        dispatch({
          type: "GET_POSTS",
          payload: {
            posts: allPosts,
            paginatedPosts: _(allPosts).slice(0).take(pageSize).value(),
          },
        });
      })
      .catch((err) => console.error(`Error: ${err}`));
  };

  const pageCount = posts ? Math.ceil(posts.length / pageSize) : 0;
  if (pageCount === 0) {
    return null;
  }
  const pages = _.range(1, pageCount + 1);

  const pagination = (pageno) => {
    setCurrentPage(pageno);
    const startIndex = (pageno - 1) * pageSize;
    const paginatedPost = _(posts).slice(startIndex).take(pageSize).value();
    dispatch({
      type: "SET_PAGINATION",
      payload: { paginatedPosts: paginatedPost },
    });
  };

  return (
    <>
      <div className="header">
        <div className="headerTitles">
          <span className="headerTitleSm">Publish your passions, your way</span>
          <span className="headerTitleLg">IDEAS MATTERS</span>
        </div>
        <img
          className="headerImg"
          src="https://images.pexels.com/photos/1167355/pexels-photo-1167355.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          alt="Posts Banner"
        />
      </div>
      <div className="Home">
        {paginatedPosts &&
          paginatedPosts.map((item) => (
            <div className="post" key={item._id}>
              <Link to={`/posts/${item._id}`} className="link">
                <div className="postInfo">
                  <div className="postCats">
                    <i className="singlePostIcon far fa-user"></i>
                    <span className="postCat">
                      <b> Author: {item.createdBy.userName}</b>
                    </span>
                  </div>
                  <span className="postTitle">{item.title}</span>
                  <hr />
                  <span className="postDate">
                    <b>{new Date(item.createdAt).toDateString()}</b>
                  </span>
                  <div className="postDesc">{item.description}</div>
                </div>
              </Link>
            </div>
          ))}
      </div>
      <nav className="d-flex justify-content-center">
        <ul className="pagination">
          {pages.map((page, index) => (
            <li
              className={
                page === currentPage ? "page-item active" : "page-item"
              }
              key={index}
            >
              <p className="page-link" onClick={() => pagination(page)}>
                {page}
              </p>
            </li>
          ))}
        </ul>
      </nav>
    </>
  );
};
export default Posts;
