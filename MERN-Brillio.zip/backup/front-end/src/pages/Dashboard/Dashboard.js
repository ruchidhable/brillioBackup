import React, { useState, useEffect } from "react";
import axios from "axios";

const Dashboard = () => {
  const [post, getPost] = useState("");

  // const url = 'http://localhost:8020';

  useEffect(() => {
    getAllPosts();
  }, []);

  const getAllPosts = () => {
    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Content-Type": "application/json",
    };

    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((res) => {
        const allPosts = res.data;
        // getAllPosts(allPosts);
        getPost(allPosts);
        console.log(allPosts);
      })
      .catch((err) => console.error(`Error: ${err}`));
  };
  return (
    <>
      <div class="album py-5 bg-light">
        <div class="container">
          <div class="row">
            {post &&
              post.map((items) => (
                <div class="col-md-4" key={items.id}>
                  <div class="card mb-4 box-shadow">
                    <div class="card-body">
                      <p class="card-text">{items.username}</p>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                          <button
                            type="button"
                            class="btn btn-sm btn-outline-secondary"
                          >
                            View
                          </button>
                          <button
                            type="button"
                            class="btn btn-sm btn-outline-secondary"
                          >
                            Edit
                          </button>
                        </div>
                        <small class="text-muted">9 mins</small>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </>
  );
};
export default Dashboard;
