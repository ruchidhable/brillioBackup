import { useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import axios from "axios";

import "./Users.css";

const Login = () => {
  const history = useHistory();
  const dispatch = useDispatch();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const onSubmitLoginHandler = (e) => {
    e.preventDefault();

    var emailAt = email.indexOf("@");
    var emailAtDot = email.indexOf(".");
    if (emailAt < 1 || emailAtDot - emailAt < 2) {
      alert("Please provide valid Email Address");
      document.loginData.email.focus();
      return;
    }

    axios
      .post("http://localhost:8000/users/login", {
        email: email,
        password: password,
      })
      .then((response) => {
        var userData = response.data;
        if (userData) {
          dispatch({
            type: "USER_LOGIN",
            payload: { token: userData.accessToken, user: userData.user },
          });

          history.replace("/");
        } else {
          alert("Invalid Credentials!");
        }
      });
  };

  return (
    <>
      <div className="container-fluid ps-md-1">
        <div className="row g-0">
          <div className="d-none d-md-flex col-md-0 col-lg-4 bg-image"></div>
          <div className="col-md-8 col-lg-5">
            <div className="login d-flex align-items-center py-5">
              <div className="container">
                <div className="row">
                  <div className="col-md-8 col-lg-11 mx-auto">
                    <h3 className="login-heading mb-4 text-center">
                      Welcome to BlogMan
                    </h3>

                    <form email="loginData" onSubmit={onSubmitLoginHandler}>
                      <div className="form-floating mb-3">
                        <label htmlFor="floatingInput">Email Address</label>
                        <input
                          type="email"
                          email="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="form-control"
                          id="floatingInput"
                          placeholder="email@example.com"
                          required
                        />
                      </div>
                      <div className="form-floating mb-3">
                        <label htmlFor="floatingPassword">Password</label>
                        <input
                          type="password"
                          email="passowrd"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="form-control"
                          id="floatingPassword"
                          placeholder="Password"
                          required
                        />
                      </div>

                      <div className="d-grid mt-4">
                        <button
                          className="btn btn-lg btn-primary btn-login text-uppercase fw-bold mb-2"
                          type="submit"
                        >
                          Login
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
