import { useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";

import "./Users.css";

const Register = () => {
  const history = useHistory();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const onSubmitRegisterHandler = (e) => {
    e.preventDefault();

    if (
      name === "" ||
      email === "" ||
      password === "" ||
      confirmPassword === ""
    ) {
      alert("Please fill out all the fields!");
      document.registerForm.name.focus();
      return;
    }

    const emailAt = email.indexOf("@");
    const emailAtDot = email.indexOf(".");
    if (emailAt < 1 || emailAtDot - emailAt < 2) {
      alert("Please provide a valid email address!");
      document.registerForm.email.focus();
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords should match with confirm password!");
      document.registerForm.password.focus();
      return;
    }

    axios
      .post("http://localhost:8000/users/register", {
        name,
        email,
        password,
      })
      .then((res) => {
        alert("User registered successfully!");
        history.replace("/login");
      })
      .catch((err) => {
        alert("Sorry, something went wrong.");
        console.log("Error: ", err);
      });
  };

  return (
    <div className="container-fluid ps-md-1">
      <div className="row g-0">
        <div className="d-none d-md-flex col-md-0 col-lg-4 bg-image"></div>
        <div className="col-md-8 col-lg-5">
          <div className="login d-flex align-items-center py-5">
            <div className="container">
              <div className="row">
                <div className="col-md-8 col-lg-11 mx-auto">
                  <form name="registerForm" onSubmit={onSubmitRegisterHandler}>
                    <div className="form-floating mb-3">
                      <label htmlFor="floatingInput">Name</label>
                      <input
                        type="text"
                        name="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="form-control"
                        id="floatingInput"
                        placeholder="John Doe"
                        required
                      />
                    </div>
                    <div className="form-floating mb-3">
                      <label htmlFor="floatingInput">Email Address</label>
                      <input
                        type="email"
                        name="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="form-control"
                        id="floatingInput"
                        placeholder="jdoe@example.com"
                        required
                      />
                    </div>

                    <div className="form-floating mb-3">
                      <label htmlFor="floatingPassword">Password</label>
                      <input
                        type="password"
                        name="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="form-control"
                        id="floatingPassword"
                        placeholder="Password"
                        required
                      />
                    </div>
                    <div className="form-floating mb-3">
                      <label htmlFor="floatingPassword">Confirm Password</label>
                      <input
                        type="password"
                        name="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="form-control"
                        id="floatingPassword"
                        placeholder="Confirm Password"
                        required
                      />
                    </div>

                    <div className="d-grid mt-5">
                      <button
                        className="btn btn-lg btn-primary btn-login text-uppercase fw-bold mb-2"
                        type="submit"
                      >
                        Register
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Register;
