import { useSelector } from "react-redux";
import { Switch, Route } from "react-router-dom";

import Posts from "../pages/Posts/Posts";
import Post from "../pages/Posts/Post";
import PostForm from "../pages/Posts/PostForm";
import Login from "../pages/Users/Login";
import Register from "../pages/Users/Register";

const Routes = () => {
  const isAuthenticated = useSelector((state) => state.user.isAuthenticated);
  return (
    <Switch>
      <Route path="/" exact component={Posts} />
      <Route path="/posts/:id" component={Post} />
      {isAuthenticated ? (
        <>
          <Route path="/add-post" component={PostForm} />
          <Route path="/edit-post/:postId" component={PostForm} />
        </>
      ) : (
        <>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register}></Route>
        </>
      )}
    </Switch>
  );
};

export default Routes;
