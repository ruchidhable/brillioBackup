const express = require("express");

const PORT = process.env.PORT || 8020;
const app = express();

app.get("/", (req, res) => {
  res.send("Reached / route.");
});

app.listen(PORT, () => {
  console.log("Server started running on port: " + PORT);
});
